
result_dir <- "Fixn"
out_dir <- file.path(result_dir, "plots", "RDPG")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

fix_n <- 2000
fix_Rho <- 0.05
fix_Rank <- NA
fix_stat <- NA
fix_eps <- NA
use_log_y <- TRUE

stat_levels <- c(
  "Node Degree",
  "V-Shape Count",
  "Triangle Count",
  "Eigen Centrality",
  "Harmonic Centrality"
)
stat_labels <- c(
  "Node Degree" = "Node Degree",
  "V-Shape Count" = "V-shape Count",
  "Triangle Count" = "Triangle Count",
  "Eigen Centrality" = "Eigen Centrality",
  "Harmonic Centrality" = "Harmonic Centrality"
)

method_cols <- c("Hat", "GRAND", "Laplace")
method_levels <- method_cols
method_labels <- c(
  Hat = "Hat (non-private)",
  GRAND = "GRAND",
  Laplace = "Laplace"
)
method_palette <- c(
  Hat = "#1F77B4",
  GRAND = "#FF7F0E",
  Laplace = "#2CA02C"
)
method_shape <- c(
  Hat = 16,
  GRAND = 17,
  Laplace = 15
)

parse_meta <- function(path) {
  x <- basename(path)
  m <- regexec(
    "^RDPG_n=([0-9]+)_Rho=([0-9.]+)_Rank=([0-9]+)_Index=([0-9]+)_Ratio=([0-9.]+)\\.Rda$",
    x
  )
  hit <- regmatches(x, m)[[1]]
  if (length(hit) == 0) return(NULL)

  data.frame(
    file = x,
    fixed_n = as.integer(hit[2]),
    Rho = as.numeric(hit[3]),
    Rank = as.integer(hit[4]),
    Index = as.integer(hit[5]),
    Ratio = as.numeric(hit[6]),
    stringsAsFactors = FALSE
  )
}

read_one <- function(path) {
  meta <- parse_meta(path)
  if (is.null(meta)) return(NULL)

  e <- new.env(parent = emptyenv())
  load(path, envir = e)
  if (!exists("res", envir = e)) {
    stop("File has no object named res: ", basename(path))
  }

  res <- get("res", envir = e)
  missing_cols <- setdiff(c("stat", "eps", method_cols), names(res))
  if (length(missing_cols) > 0) {
    stop("Missing columns in ", basename(path), ": ", paste(missing_cols, collapse = ", "))
  }

  rows <- list()
  k <- 1
  for (method in method_cols) {
    rows[[k]] <- data.frame(
      meta[rep(1, nrow(res)), ],
      stat = res$stat,
      eps = res$eps,
      method = method,
      W1 = as.numeric(res[[method]]),
      row.names = NULL,
      stringsAsFactors = FALSE
    )
    k <- k + 1
  }
  do.call(rbind, rows)
}

files <- list.files(result_dir, pattern = "^RDPG_n=.*\\.Rda$", full.names = TRUE)
all_w1 <- do.call(rbind, lapply(files, read_one))

if (!is.na(fix_n)) all_w1 <- all_w1[all_w1$fixed_n == fix_n, ]
if (!is.na(fix_Rho)) all_w1 <- all_w1[all_w1$Rho == fix_Rho, ]
if (!is.na(fix_Rank)) all_w1 <- all_w1[all_w1$Rank == fix_Rank, ]
if (!is.na(fix_stat)) all_w1 <- all_w1[all_w1$stat == fix_stat, ]
if (!is.na(fix_eps)) all_w1 <- all_w1[all_w1$eps == fix_eps, ]

if (nrow(all_w1) == 0) {
  stop("No records left after filtering. Check fix_n/fix_Rho/fix_Rank/fix_stat/fix_eps.")
}
unknown_stats <- setdiff(unique(as.character(all_w1$stat)), stat_levels)
if (length(unknown_stats) > 0) {
  stop("Unexpected stat values: ", paste(unknown_stats, collapse = ", "))
}
all_w1$stat <- factor(all_w1$stat, levels = stat_levels)
all_w1$method <- factor(all_w1$method, levels = method_levels)
all_w1$eps <- factor(all_w1$eps, levels = sort(unique(as.numeric(all_w1$eps))))

write.csv(all_w1, file.path(out_dir, "all_w1_long.csv"), row.names = FALSE)

summary_w1 <- aggregate(
  W1 ~ fixed_n + Rho + Rank + Ratio + stat + eps + method,
  all_w1,
  function(z) {
    c(
      mean = mean(z, na.rm = TRUE),
      sd = sd(z, na.rm = TRUE),
      se = sd(z, na.rm = TRUE) / sqrt(sum(!is.na(z))),
      n = sum(!is.na(z))
    )
  }
)
summary_w1 <- do.call(data.frame, summary_w1)
names(summary_w1)[names(summary_w1) == "W1.mean"] <- "mean"
names(summary_w1)[names(summary_w1) == "W1.sd"] <- "sd"
names(summary_w1)[names(summary_w1) == "W1.se"] <- "se"
names(summary_w1)[names(summary_w1) == "W1.n"] <- "n"
summary_w1$method <- factor(summary_w1$method, levels = method_levels)
summary_w1$stat <- factor(summary_w1$stat, levels = stat_levels)
summary_w1$Rank <- factor(summary_w1$Rank, levels = sort(unique(summary_w1$Rank)))
summary_w1$eps <- factor(summary_w1$eps, levels = sort(unique(as.numeric(as.character(summary_w1$eps)))))
min_positive_mean <- min(summary_w1$mean[summary_w1$mean > 0], na.rm = TRUE)
summary_w1$lower <- if (use_log_y) {
  pmax(summary_w1$mean - summary_w1$se, min_positive_mean * 0.5)
} else {
  pmax(summary_w1$mean - summary_w1$se, 0)
}
summary_w1$upper <- summary_w1$mean + summary_w1$se

write.csv(summary_w1, file.path(out_dir, "w1_summary_by_ratio.csv"), row.names = FALSE)

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  stop("Please install ggplot2 first: install.packages('ggplot2')")
}

library(ggplot2)

publication_theme <- function(base_size = 14.5) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(face = "plain"),
      axis.title = element_text(face = "plain", size = base_size + 1.3),
      axis.text = element_text(face = "plain", color = "grey15", size = 12.5),
      axis.line = element_blank(),
      axis.ticks = element_line(color = "grey25", linewidth = 0.35),
      panel.border = element_rect(color = "grey25", fill = NA, linewidth = 0.5),
      panel.grid.major = element_line(color = "grey88", linewidth = 0.25),
      panel.grid.minor = element_blank(),
      strip.background = element_rect(fill = "grey96", color = "grey25", linewidth = 0.35),
      strip.background.y = element_blank(),
      strip.text = element_text(face = "plain", color = "grey10", size = base_size - 0.6),
      strip.text.y.left = element_text(face = "plain", angle = 0, hjust = 1, margin = margin(r = 6)),
      strip.placement = "outside",
      legend.position = "bottom",
      legend.title = element_text(face = "plain", size = base_size, margin = margin(r = 14)),
      legend.text = element_text(face = "plain", size = base_size),
      legend.key.width = grid::unit(1.6, "lines"),
      legend.background = element_blank(),
      plot.margin = margin(8, 10, 8, 8),
      panel.spacing.x = grid::unit(0.9, "lines"),
      panel.spacing.y = grid::unit(0.75, "lines")
    )
}

y_axis_label <- if (use_log_y) {
  "Wasserstein Distance (log)"
} else {
  expression(bold(W[1]~" distance"))
}
y_scale <- function() {
  if (use_log_y) {
    scale_y_log10(expand = expansion(mult = c(0.03, 0.08)))
  } else {
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.08)))
  }
}
ratio_breaks <- c(10, 20, 30, 40, 50)
ratio_labels <- c("0.2", "0.4", "0.6", "0.8", "1.0")
eps_labeller <- function(x) paste0("varepsilon = ", x)

make_rank_plot <- function(rank_value) {
  d <- summary_w1[summary_w1$Rank == rank_value, ]
  pd <- position_dodge(width = 0.75)

  ggplot(
    d,
    aes(
      x = Ratio,
      y = mean,
      color = method,
      shape = method,
      group = method
    )
  ) +
    geom_errorbar(
      aes(ymin = lower, ymax = upper),
      width = 1.15,
      linewidth = 0.58,
      alpha = 0.68,
      position = pd,
      show.legend = FALSE
    ) +
    geom_line(linewidth = 0.78, alpha = 0.96, position = pd) +
    geom_point(size = 1.75, stroke = 0.25, alpha = 0.98, position = pd) +
    facet_grid(
      stat ~ eps,
      scales = "free_y",
      labeller = labeller(stat = stat_labels, eps = eps_labeller),
      switch = "y"
    ) +
    scale_color_manual(name = "m/n Ratio", values = method_palette,
                       breaks = method_levels, labels = method_labels,
                       limits = method_levels, drop = FALSE) +
    scale_shape_manual(name = "m/n Ratio", values = method_shape,
                       breaks = method_levels, labels = method_labels,
                       limits = method_levels, drop = FALSE) +
    scale_x_continuous(
      breaks = ratio_breaks,
      labels = ratio_labels,
      limits = c(8, 52),
      expand = expansion(mult = c(0.03, 0.05))
    ) +
    y_scale() +
    labs(
      x = NULL,
      y = y_axis_label
    ) +
    guides(
      color = guide_legend(nrow = 1),
      shape = guide_legend(nrow = 1)
    ) +
    publication_theme(base_size = 14.5) +
    theme(
      strip.text.y = element_text(face = "plain", angle = 0, size = 14),
      strip.text.x = element_text(face = "plain", size = 14),
      axis.text.y = element_text(face = "plain"),
      axis.title.x = element_text(face = "plain", margin = margin(t = 5)),
      axis.title.y = element_text(face = "plain", margin = margin(r = 5))
    )
}

for (rr in levels(summary_w1$Rank)) {
  p_rank <- make_rank_plot(rr)
  rank_tag <- gsub("[^A-Za-z0-9]+", "_", rr)
  png_file <- file.path(out_dir, paste0("w1_vs_ratio_rank", rank_tag, "_all_panels.png"))
  png_temp <- tempfile(fileext = ".png")
  ggsave(png_temp, p_rank, width = 13.8, height = 7.2, dpi = 600)
  if (!file.copy(png_temp, png_file, overwrite = TRUE)) {
    stop("Could not save PNG file: ", png_file)
  }
  unlink(png_temp)
  ggsave(file.path(out_dir, paste0("w1_vs_ratio_rank", rank_tag, "_all_panels.pdf")),
         p_rank, width = 13.8, height = 7.2, device = cairo_pdf)
}

message("Done. Outputs written to: ", normalizePath(out_dir))



