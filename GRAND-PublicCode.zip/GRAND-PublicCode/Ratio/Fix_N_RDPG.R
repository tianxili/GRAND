custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)

rep.m <- 100

N.seq <- c(4000)
rho.seq <- c(0.05)
rank.seq <- c(3)
ratio.seq <- c(10, 20, 30, 40, 50)

dir.create("Fix_N", showWarnings = FALSE)

for (I1 in 1:length(N.seq)) {
  for (I2 in 1:length(rho.seq)) {
    for (I3 in 1:length(rank.seq)) {
      for (I4 in 1:length(ratio.seq)) {
        N.val <- N.seq[I1]
        rho.val <- rho.seq[I2]
        rank.val <- rank.seq[I3]
        ratio.val <- ratio.seq[I4]

        foreach(
          i = 1:rep.m,
          .packages = c("randnet", "GRANDpriv"),
          .errorhandling = "pass"
        ) %dopar% {
          filename <- paste(
            "./Fix_N/RDPG_N=", N.val,
            "_Rho=", rho.val,
            "_Rank=", rank.val,
            "_Index=", i,
            "_Ratio=", ratio.val,
            ".Rda",
            sep = ""
          )

          if (!file.exists(filename)) {
            m <- N.val * ratio.val / 100
            n <- N.val * (1 - ratio.val / 100)
            dt <- RDPG.Gen(n = m + n, K = rank.val, directed = FALSE, avg.d = rho.val * (m + n))
            A <- dt$A
            idx <- 1:n
            test <- GRAND.privatize(A, rank.val, idx, eps = c(1, 2, 5, 10), model = "RDPG")
            res <- GRAND.evaluate(test)

            save(res, file = filename)
            gc()
          }

          NULL
        }
      }
    }
  }
}
