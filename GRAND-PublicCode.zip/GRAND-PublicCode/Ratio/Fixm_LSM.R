custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)

rep.m <- 100

m.seq <- c(2000)
rho.seq <- c(0.05)
rank.seq <- c(3)
ratio.seq <- c(10, 20, 30, 40, 50)

dir.create("Fixm", showWarnings = FALSE)

for (I1 in seq_along(m.seq)) {
  for (I2 in seq_along(rho.seq)) {
    for (I3 in seq_along(rank.seq)) {
      for (I4 in seq_along(ratio.seq)) {
        m.val <- m.seq[I1]
        rho.val <- rho.seq[I2]
        rank.val <- rank.seq[I3]
        ratio.val <- ratio.seq[I4]

        foreach(
          i = seq_len(rep.m),
          .packages = c("randnet", "GRANDpriv"),
          .errorhandling = "pass"
        ) %dopar% {
          filename <- paste(
            "./Fixm/LSM_m=", m.val,
            "_Rho=", rho.val,
            "_Rank=", rank.val,
            "_Index=", i,
            "_Ratio=", ratio.val,
            ".Rda",
            sep = ""
          )
          
          if (!file.exists(filename)) {
            m <- m.val
            n <- m.val * ratio.val / 10
            dt <- LSM.Gen(n = m + n, k = rank.val, K = 5, avg.d = rho.val * (m + n))
            A <- dt$A
            idx <- 1:n
            test <- GRAND.privatize(A, rank.val, idx, eps = c(1, 2, 5, 10), model = "LSM")
            res <- GRAND.evaluate(test)

            save(res, file = filename)
            gc()
          }
          
          NULL
        }
      }
    }
  }
}
