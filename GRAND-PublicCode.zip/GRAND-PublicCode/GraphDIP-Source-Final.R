library(rmutil)
library(EnvStats)
library(prodlim)
library(xtable)
library(diffpriv)
library(randnet)
library(RSpectra)
library(irlba)
library(HCD)
library(igraph)
library(truncnorm)
library(transport)

source("Core-DP-Subfunctions.R")
f <- function(X) X ## target function

ase <- function(A,K){
  A2 <- A^T%*%A
  eig <- eigs_sym(A2,k=K)
  Xhat <- t(t(eig$vectors[,1:K, drop = FALSE])*eig$values[1:K]^(1/4))
  return(Xhat)
}
two.to.inf <- function(X){
  max(apply(X^2,1,sum))
}

net2mom <- function(A){
  k <- nrow(A)
  diag(A) <- 0

  A2 <- A %*% A
  diag(A2) <- 0

  Uv <- sum(A2)/(k*(k-1)*(k-2)/3)

  Xv_exact <- sum(cal_k_star(A,2))

  Uv_exact <- (Xv_exact/(k*(k-1)*(k-2)/6))

  Utri <- sum(diag(A %*% A %*% A)) / (k*(k-1)*(k-2))

  vv <- colSums(A)
  vv2 <- colSums(A^2)
  vv3 <- colSums(A^3)

  Utstar <- sum(vv^3 - 3*vv2*vv + 2*vv3) /6 / (k*(k-1)*(k-2)*(k-3)/24)
  Xstar_exact <- sum(cal_k_star(A,3))
  Utstar_exact <-  ( Xstar_exact/ (k*(k-1)*(k-2)*(k-3)/24))




  return(list(UR = c(Uv,Utri,Utstar), UR_exact = c(Uv_exact,  Utri, Utstar_exact)))
}

get.stats <- function(g){
  n <- length(V(g))

  edge.count <- length(E(g))

  tri <- sum(count_triangles(g))/3

  over.count <- sum((degree(g) * (degree(g)-1)/2))

  sup.v.count <- over.count - tri*2

  stats <- c(edge.count/choose(n=n,k=2),sup.v.count/choose(n=n,k=3),tri/choose(n=n,k=3))

  rho.n <- edge.count/choose(n=n,k=2)

  stats <- stats/c(rho.n^1,rho.n^2,rho.n^3)

  return(stats)

}

Add.Laplace <- function(X,eps=1){
  p <- ncol(X)
  n <- nrow(X)
  pparams <- DPParamsEps(epsilon = eps/p) ## desired privacy budget
  print(pparams)
  X_lap=X
  for (j in 1:p){ #Post processing; truncating unreasonably large values
    mechanism <- DPMechLaplace(target = f, sensitivity = max(abs(X[,j])), dims = n)
    r_lap <- releaseResponse(mechanism, privacyParams = pparams, X = X[,j])
    X_lap[,j]=r_lap$response
  }
  return(X_lap)
}

LSM.Gen <- function(n, k, K, avg.d = NULL) {
  alpha <- runif(n, 1, 3)
  alpha <- -alpha / 2

  mu <- matrix(runif(K * k, -1, 1), K, k)
  idx <- sample(1:K, n, replace = TRUE)
  mu <- mu[idx, ]

  Z <- mu + matrix(rtruncnorm(n * k, -2, 2), n, k)
  J <- diag(n) - rep(1, n)%*%t(rep(1, n))/ n
  Z <- J%*%Z
  G <- Z%*%t(Z)
  Z <- Z / sqrt(sqrt(sum(G ^ 2)) / n)

  theta <- alpha%*%t(rep(1, n)) + rep(1, n)%*%t(alpha) + Z%*%t(Z)
  P <- 1 / (1 + exp(-theta))

  if(!is.null(avg.d)){
    for (i in 1:10) {
      ratio <- mean(rowSums(P)) / avg.d
      beta <- -log(ratio)
      alpha <- alpha + beta / 2
      theta <- alpha%*%t(rep(1, n)) + rep(1, n)%*%t(alpha) + Z%*%t(Z)
      P <- 1 / (1 + exp(-theta))
    }
  }

  upper.index <- which(upper.tri(P))
  upper.p <- P[upper.index]
  upper.u <- runif(length(upper.p))
  upper.A <- rep(0, length(upper.p))
  upper.A[upper.u < upper.p] <- 1
  A <- matrix(0, n, n)
  A[upper.index] <- upper.A
  A <- A + t(A)
  diag(A) <- 0

  return(list(A = A, g = idx, P = P, alpha = alpha, Z = Z))
}




### New LSM fitting function on one node (row and column), based on partially estimated latent positions.
### The model fitting is based on the logistic regression interpretation, using the estimated latent positions rather than the true latent positions.
### The core model fitting is calling the glm function in R.

LSM.one.node <- function(A,given.index,new.index,given.Z,given.alpha){
  n <- nrow(A)
  p <- ncol(given.Z)
  n1 <- length(given.index)
  n2 <- length(new.index)

  Y <- A[new.index,given.index]
  fit <- glm(Y ~ given.Z, family = binomial(),offset = given.alpha,maxit=1000)  
  return(fit)
}


### New LSM fitting function 
### NDP without requiring a latent space model to be true.

LSM.NDP.estimate <- function(A,K,holdout.index,release.index,niter=500){
  m <- length(holdout.index)
  n <- length(release.index)
  A22 <- A[holdout.index,holdout.index]
  fitting.count <- 0
  while(fitting.count<5){
    fit.holdout <- LSM.PGD.CPP(A22,k=K,niter=niter)
    fitting.count <- fitting.count + 1
    if(sum(is.na(fit.holdout$Z))==0){
      break
    }
  }
  if(sum(colSums(abs(fit.holdout$Z))<1e-4)>0){
    print(paste("Potential defficiency of ",sum(colSums(abs(fit.holdout$Z))<1e-4)))
  }
  
  
  print(paste(("PGD used"),length(fit.holdout$obj),"iterations"))
  Z.holdout <- fit.holdout$Z
  alpha.holdout <- fit.holdout$alpha
  Zhat <- matrix(0,nrow=n+m,ncol=K)
  alpha.hat <- rep(0,n+m)
  Zhat[holdout.index,] <- Z.holdout
  alpha.hat[holdout.index] <- alpha.holdout
  for(j in 1:n){
    fit <- LSM.one.node(A,given.index=holdout.index,new.index=release.index[j],given.Z=Z.holdout,given.alpha=alpha.holdout)
    Zhat[release.index[j],] <- fit$coefficients[2:(K+1)]
    alpha.hat[release.index[j]] <- fit$coefficients[1]
  }
  return(list(Z=Zhat,alpha=alpha.hat))
}



LSM.NDP.combined.all <- function(A, K, idx, eps = 1,oracle.dt=NULL,niter=500){
  n <- nrow(A)
  n1 <- length(idx)
  n2 <- nrow(A)-n1
  holdout.idx <- setdiff(1:nrow(A),idx)
  A11 <- A[idx, idx]
  g1 <- graph.adjacency(A11,"undirected")
  A22 <- A[holdout.idx, holdout.idx]
  g2 <- graph.adjacency(A22,"undirected")
  
  LSM.fit <- LSM.NDP.estimate(A=A,K=K,holdout.index=holdout.idx,release.index=idx,niter=niter)
  X.trans <- cbind(LSM.fit$alpha, LSM.fit$Z)

  X1.hat <- X.trans[idx, ]
  X2.hat <- X.trans[holdout.idx,]

  ### create non-private estimate
  alpha1.hat <- matrix(X1.hat[, 1],nrow=nrow(X1.hat))
  Z1.hat <- matrix(X1.hat[, -1],nrow=nrow(X1.hat))
  theta1.hat <- alpha1.hat%*%t(rep(1, n1)) + rep(1, n1)%*%t(alpha1.hat) + Z1.hat%*%t(Z1.hat)
  P1.hat <- 1 / (1 + exp(-theta1.hat))
  A1.hat <- gen.A.from.P(P1.hat)
  g1.hat <- graph.adjacency(A1.hat, "undirected")
  
  ### non-private estimation based on only the hold-out part
  alpha2.hat <- matrix(X2.hat[, 1],nrow=nrow(X2.hat))
  Z2.hat <- matrix(X2.hat[, -1],nrow=nrow(X2.hat))
  theta2.hat <- alpha2.hat%*%t(rep(1, n2)) + rep(1, n2)%*%t(alpha2.hat) + Z2.hat%*%t(Z2.hat)
  P2.hat <- 1 / (1 + exp(-theta2.hat))
  A2.hat <- gen.A.from.P(P2.hat)
  g2.hat <- graph.adjacency(A2.hat, "undirected")
  
  
  non.private.result <- list(g1 = g1,g2=g2, g1.hat = g1.hat, g2.hat=g2.hat,
                             X1.hat = X1.hat, X2.hat=X2.hat)
  L <- length(eps)
  DIP.result <- list()
  oracle.DIP.result <- list()
  if(!is.null(oracle.dt)){
    oracle.X1 <- cbind(oracle.dt$alpha[idx],oracle.dt$Z[idx,])
    oracle.X2 <- cbind(oracle.dt$alpha[holdout.idx],oracle.dt$Z[holdout.idx,])
  }
  for(jj in 1:L){
    cat(paste("Calling DIP with ε=", eps[jj], "\n", sep = ""))
    X1.dip <- dip_mv_new(X1.hat, eps[jj], X2.hat)
    cat("finish multivariate DIP\n")
    alpha1.dip <- matrix(X1.dip[, 1],nrow=nrow(X1.dip))
    Z1.dip <- matrix(X1.dip[, -1],nrow=nrow(X1.dip))
    theta1.dip <- alpha1.dip%*%t(rep(1, n1)) + rep(1, n1)%*%t(alpha1.dip) + Z1.dip%*%t(Z1.dip)
    P1.dip <- 1 / (1 + exp(-theta1.dip))
    A1.dip <- gen.A.from.P(P1.dip)
    g1.dip <- graph.adjacency(A1.dip, "undirected")
    DIP.result[[jj]] <- list( g1.dip = g1.dip,X1.dip = X1.dip)
    
    if(!is.null(oracle.dt)){
      cat("Call the oracle version\n")
      cat(paste("Calling DIP with ε=", eps[jj], "\n", sep = ""))
      oracle.X1.dip <- dip_mv_new(oracle.X1, eps[jj], oracle.X2)
      cat("finish multivariate DIP\n")
      oracle.alpha1.dip <- matrix(oracle.X1.dip[, 1],nrow=nrow(oracle.X1.dip))
      oracle.Z1.dip <- matrix(oracle.X1.dip[, -1],nrow=nrow(oracle.X1.dip))
      oracle.theta1.dip <- oracle.alpha1.dip%*%t(rep(1, n1)) + rep(1, n1)%*%t(oracle.alpha1.dip) + oracle.Z1.dip%*%t(oracle.Z1.dip)
      oracle.P1.dip <- 1 / (1 + exp(-oracle.theta1.dip))
      oracle.A1.dip <- gen.A.from.P(oracle.P1.dip)
      oracle.g1.dip <- graph.adjacency(oracle.A1.dip, "undirected")
      oracle.DIP.result[[jj]] <- list( g1.dip = oracle.g1.dip,X1.dip = oracle.X1.dip)
      
    }
  }
  
   

  ##### naive Laplace method
  X.tilde <- X.trans

  X1.hat <- X.tilde[idx, ]

  Laplace.result <- list()
  for(jj in 1:L){
    cat(paste("Calling Laplace with ε=", eps[jj], "\n", sep=""))
    X1.Lap <- Add.Laplace(X = X1.hat, eps = eps[jj])
    
    alpha1.Lap <- X1.Lap[, 1]
    Z1.Lap <- X1.Lap[, -1]
    theta1.Lap <- alpha1.Lap%*%t(rep(1, n1)) + rep(1, n1)%*%t(alpha1.Lap) + Z1.Lap%*%t(Z1.Lap)
    P1.Lap <- 1 / (1 + exp(-theta1.Lap))
    
    A1.Lap <- gen.A.from.P(P1.Lap)
    
    g1 <- graph.adjacency(A11,"undirected")
    g1.Lap <- graph.adjacency(A1.Lap,"undirected")
    Laplace.result[[jj]] <- list(g1.Lap = g1.Lap, X1.Lap=X1.Lap)
    
  }

  return(list(non.private.result=non.private.result,DIP.result=DIP.result,Laplace.result=Laplace.result,eps=eps,oracle.DIP.result=oracle.DIP.result))

}





DIP.eval.summary <- function(test1){
  degree.true <- log(1+degree(test1$non.private.result$g1))
  degree.hat <- log(1+degree(test1$non.private.result$g1.hat))
  degree.true2 <- log(1+degree(test1$non.private.result$g2))
  degree.hat2 <- log(1+degree(test1$non.private.result$g2.hat))
  degree.dip <- lapply(test1$DIP.result,function(x){
    log(1+degree(x$g1.dip))
  })
  degree.lap <- lapply(test1$Laplace.result,function(x){
    log(1+degree(x$g1.Lap))
  })
  

degree.mat <- data.frame(eps=test1$eps,
                         metric = rep("Degree",length(test1$eps)),
                         Hat=rep(wasserstein1d(degree.true, degree.hat),length(test1$eps)),
                         Hat2=rep(wasserstein1d(degree.true2, degree.hat2),length(test1$eps)),
                         DIP = unlist(lapply(degree.dip,function(x){
                           wasserstein1d(degree.true, x)
                         })),
                         Lap = unlist(lapply(degree.lap,function(x){
                           wasserstein1d(degree.true, x)
                         }))
                         )
if(length(test1$oracle.DIP.result)>0){
  degree.dip.oracle <- lapply(test1$oracle.DIP.result,function(x){
    degree(x$g1.dip)
  })
  degree.mat$Oracle <- unlist(lapply(degree.dip.oracle,function(x){
    wasserstein1d(degree.true, x)
  }))
}else{
  degree.mat$Oracle <- NA
}



tri.true <- log(1+count_triangles(test1$non.private.result$g1))
tri.hat <- log(1+count_triangles(test1$non.private.result$g1.hat))
tri.true2 <- log(1+count_triangles(test1$non.private.result$g2))
tri.hat2 <- log(1+count_triangles(test1$non.private.result$g2.hat))
tri.dip <- lapply(test1$DIP.result,function(x){
  log(1+count_triangles(x$g1.dip))
})
tri.lap <- lapply(test1$Laplace.result,function(x){
  log(1+count_triangles(x$g1.Lap))
})

tri.mat <- data.frame(eps=test1$eps,
                      metric = rep("Triangle",length(test1$eps)),
                      Hat=rep(wasserstein1d(tri.true, tri.hat),length(test1$eps)),
                      Hat2=rep(wasserstein1d(tri.true2, tri.hat2),length(test1$eps)),
                      DIP = unlist(lapply(tri.dip,function(x){
                        wasserstein1d(tri.true, x)
                      })),
                      Lap = unlist(lapply(tri.lap,function(x){
                        wasserstein1d(tri.true, x)
                      }))
)
if(length(test1$oracle.DIP.result)>0){
  tri.dip.oracle <- lapply(test1$oracle.DIP.result,function(x){
    log(1+count_triangles(x$g1.dip))
  })
  tri.mat$Oracle <- unlist(lapply(tri.dip.oracle,function(x){
    wasserstein1d(tri.true, x)
  }))
}else{
  tri.mat$Oracle <- NA
}


vs.true <- log(1+get.v(test1$non.private.result$g1))
vs.hat <- log(1+get.v(test1$non.private.result$g1.hat))
vs.true2 <- log(1+get.v(test1$non.private.result$g2))
vs.hat2 <- log(1+get.v(test1$non.private.result$g2.hat))
vs.dip <- lapply(test1$DIP.result,function(x){
  log(1+get.v(x$g1.dip))
})
vs.lap <- lapply(test1$Laplace.result,function(x){
  log(1+get.v(x$g1.Lap))
})

vs.mat <- data.frame(eps=test1$eps,
                     metric = rep("VS",length(test1$eps)),
                     Hat=rep(wasserstein1d(vs.true, vs.hat),length(test1$eps)),
                     Hat2=rep(wasserstein1d(vs.true2, vs.hat2),length(test1$eps)),
                     DIP = unlist(lapply(vs.dip,function(x){
                       wasserstein1d(vs.true, x)
                     })),
                     Lap = unlist(lapply(vs.lap,function(x){
                       wasserstein1d(vs.true, x)
                     }))
)
if(length(test1$oracle.DIP.result)>0){
  vs.dip.oracle <- lapply(test1$oracle.DIP.result,function(x){
    log(1+get.v(x$g1.dip))
  })
  vs.mat$Oracle <- unlist(lapply(vs.dip.oracle,function(x){
    wasserstein1d(vs.true, x)
  }))
}else{
  vs.mat$Oracle <- NA
}



eigen.true <- eigen_centrality(test1$non.private.result$g1)$vector
eigen.hat <- eigen_centrality(test1$non.private.result$g1.hat)$vector
eigen.true2 <- eigen_centrality(test1$non.private.result$g2)$vector
eigen.hat2 <- eigen_centrality(test1$non.private.result$g2.hat)$vector
eigen.dip <- lapply(test1$DIP.result,function(x){
  eigen_centrality(x$g1.dip)$vector  
})
eigen.lap <- lapply(test1$Laplace.result,function(x){
  eigen_centrality(x$g1.Lap)$vector  
})

eigen.mat <- data.frame(eps=test1$eps,
                        metric = rep("Eigen",length(test1$eps)),
                        Hat=rep(wasserstein1d(eigen.true, eigen.hat),length(test1$eps)),
                        Hat2=rep(wasserstein1d(eigen.true2, eigen.hat2),length(test1$eps)),
                        DIP = unlist(lapply(eigen.dip,function(x){
                          wasserstein1d(eigen.true, x)
                        })),
                        Lap = unlist(lapply(eigen.lap,function(x){
                          wasserstein1d(eigen.true, x)
                        }))
)
if(length(test1$oracle.DIP.result)>0){
  eigen.dip.oracle <- lapply(test1$oracle.DIP.result,function(x){
    eigen_centrality(x$g1.dip)$vector  
  })
  eigen.mat$Oracle <- unlist(lapply(eigen.dip.oracle,function(x){
    wasserstein1d(eigen.true, x)
  }))
}else{
  eigen.mat$Oracle <- NA
}



harmonic.true <- harmonic_centrality(test1$non.private.result$g1)
harmonic.hat <- harmonic_centrality(test1$non.private.result$g1.hat)
harmonic.true2 <- harmonic_centrality(test1$non.private.result$g2)
harmonic.hat2 <- harmonic_centrality(test1$non.private.result$g2.hat)
harmonic.dip <- lapply(test1$DIP.result,function(x){
  harmonic_centrality(x$g1.dip)
})
harmonic.lap <- lapply(test1$Laplace.result,function(x){
  harmonic_centrality(x$g1.Lap)
})

harmonic.mat <- data.frame(eps=test1$eps,
                           metric = rep("Harmonic",length(test1$eps)),
                           Hat=rep(wasserstein1d(harmonic.true, harmonic.hat),length(test1$eps)),
                           Hat2=rep(wasserstein1d(harmonic.true2, harmonic.hat2),length(test1$eps)),
                           DIP = unlist(lapply(harmonic.dip,function(x){
                             wasserstein1d(harmonic.true, x)
                           })),
                           Lap = unlist(lapply(harmonic.lap,function(x){
                             wasserstein1d(harmonic.true, x)
                           }))
)
if(length(test1$oracle.DIP.result)>0){
  harmonic.dip.oracle <- lapply(test1$oracle.DIP.result,function(x){
    harmonic_centrality(x$g1.dip)
  })
  harmonic.mat$Oracle <- unlist(lapply(harmonic.dip.oracle,function(x){
    wasserstein1d(harmonic.true, x)
  }))
}else{
  harmonic.mat$Oracle <- NA
}


return(rbind(degree.mat,vs.mat,tri.mat,eigen.mat,harmonic.mat))
}




library(Rcpp)
sourceCpp("LSM_PGD_Cpp.cpp")  # adjust the filename/path as needed

library(RSpectra)

# Logit and sigmoid functions
logit <- function(p) { log(p / (1 - p)) }
sigmoid <- function(x) { 1 / (1 + exp(-x)) }

LSM.PGD.CPP <- function(A, k, step.size = 0.3, niter = 500, trace = 0) {
  N <- nrow(A)
  ones <- rep(1, N)
  M <- matrix(1, N, N)
  Jmat <- diag(rep(1, N)) - M / N
  
  P.tilde <- USVT(A)
  P.tilde[P.tilde > (1 - 1e-5)] <- (1 - 1e-5)
  P.tilde[P.tilde < 1e-5] <- 1e-5
  
  Theta.tilde <- logit(P.tilde)
  
  alpha_0 <- solve(N * diag(rep(1, N)) + M, rowSums(Theta.tilde))
  
  G <- Jmat %*% (Theta.tilde - outer(alpha_0, alpha_0, "+")) %*% Jmat
  
  eig <- eigs_sym(A = G, k = k)
  eig$values[eig$values <= 0] <- 0
  
  Z_0 <- t(t(eig$vectors[, 1:k]) * sqrt(eig$values[1:k]))
  step.size.z <- step.size / norm(Z_0, "2")^2
  step.size.alpha <- step.size / (2 * N)
  
  # Call the C++ function
  res <- LSM_PGD_Cpp(A, Z_0, alpha_0, step.size.z, step.size.alpha, niter, trace = (trace > 0))
  return(res)
}








### New RDPG fitting function on one node (row and column), based on partially estimated latent positions.
### The model fitting is based on the linear regression interpretation, using the estimated latent positions rather than the true latent positions.
### The core model fitting is calling the lm function in R.

RDPG.one.node <- function(A,given.index,new.index,given.Z){
  n <- nrow(A)
  p <- ncol(given.Z)
  n1 <- length(given.index)
  n2 <- length(new.index)
  
  Y <- A[new.index,given.index]
  fit <- lm(Y ~ given.Z-1)  
  return(fit)
}


### New RDPG fitting function -- it satisfies a stronger DP guarantee, as it is
### NDP without requiring a latent space model to be true.

RDPG.NDP.estimate <- function(A,K,holdout.index,release.index){
  m <- length(holdout.index)
  n <- length(release.index)
  A22 <- A[holdout.index,holdout.index]
  Z.holdout <- ase(A22,K)
  Zhat <- matrix(0,nrow=n+m,ncol=K)
  Zhat[holdout.index,] <- Z.holdout
    for(j in 1:n){
    fit <- RDPG.one.node(A,given.index=holdout.index,new.index=release.index[j],given.Z=Z.holdout)
    Zhat[release.index[j],] <- fit$coefficients[1:K]
  }
  return(list(Z=Zhat))
}



RDPG.NDP.combined.all <- function(A, K, idx, eps = 1,oracle.dt=NULL){
  n <- nrow(A)
  n1 <- length(idx)
  n2 <- nrow(A)-n1
  holdout.idx <- setdiff(1:nrow(A),idx)
  A11 <- A[idx, idx]
  g1 <- graph.adjacency(A11,"undirected")
  A22 <- A[holdout.idx, holdout.idx]
  g2 <- graph.adjacency(A22,"undirected")
  
  RDPG.fit <- RDPG.NDP.estimate(A=A,K=K,holdout.index=holdout.idx,release.index=idx)
  X.trans <- RDPG.fit$Z
  
  X1.hat <- X.trans[idx, ,drop=FALSE]
  X2.hat <- X.trans[holdout.idx,,drop=FALSE]
  
  ### create non-private estimate
  Z1.hat <- matrix(X1.hat,nrow=nrow(X1.hat))
  theta1.hat <- Z1.hat%*%t(Z1.hat)
  P1.hat <- theta1.hat
  P1.hat[theta1.hat>(1-1e-5)] <- 1-1e-5
  P1.hat[theta1.hat< 1e-5] <- 1e-5
  
  A1.hat <- gen.A.from.P(P1.hat)
  g1.hat <- graph.adjacency(A1.hat, "undirected")
  

  ### non-private estimation based on only the hold-out part
  Z2.hat <- matrix(X2.hat,nrow=nrow(X2.hat))
  theta2.hat <- Z2.hat%*%t(Z2.hat)
  P2.hat <- theta2.hat
  P2.hat[theta2.hat>(1-1e-5)] <- 1-1e-5
  P2.hat[theta2.hat< 1e-5] <- 1e-5
  
  A2.hat <- gen.A.from.P(P2.hat)
  g2.hat <- graph.adjacency(A2.hat, "undirected")
  
  
  non.private.result <- list(g1 = g1,g2=g2, g1.hat = g1.hat, g2.hat=g2.hat,
                             Z1.hat = Z1.hat, Z2.hat=Z2.hat)
  L <- length(eps)
  DIP.result <- list()
  oracle.DIP.result <- list()
  if(!is.null(oracle.dt)){
    ASE.oracle <- ase(oracle.dt$P, K)
    oracle.X1 <- ASE.oracle[idx,,drop=FALSE]
    oracle.X2 <- ASE.oracle[holdout.idx,,drop=FALSE]
  }
  for(jj in 1:L){
    cat(paste("Calling DIP with ε=", eps[jj], "\n", sep = ""))
    X1.dip <- dip_mv_new(X1.hat, eps[jj], X2.hat)
    cat("finish multivariate DIP\n")
    Z1.dip <- matrix(X1.dip,nrow=nrow(X1.dip))
    theta1.dip <- Z1.dip%*%t(Z1.dip)
    P1.dip <- theta1.dip
    P1.dip[theta1.dip>(1-1e-5)] <- 1-1e-5
    P1.dip[theta1.dip< 1e-5] <- 1e-5
    
    A1.dip <- gen.A.from.P(P1.dip)
    g1.dip <- graph.adjacency(A1.dip, "undirected")
    DIP.result[[jj]] <- list( g1.dip = g1.dip,X1.dip = X1.dip)
    if(!is.null(oracle.dt)){
      cat("Call the oracle version\n")
      cat(paste("Calling DIP with ε=", eps[jj], "\n", sep = ""))
      oracle.X1.dip <- dip_mv_new(oracle.X1, eps[jj], oracle.X2)
      oracle.Z.dip <- matrix(oracle.X1.dip,nrow=nrow(X1.dip))
      cat("finish multivariate DIP\n")
      oracle.theta1.dip <- oracle.Z.dip%*%t(oracle.Z.dip)
      oracle.P1.dip <- oracle.theta1.dip
      oracle.P1.dip[theta1.dip>(1-1e-5)] <- 1-1e-5
      oracle.P1.dip[theta1.dip< 1e-5] <- 1e-5
      
      oracle.A1.dip <- gen.A.from.P(oracle.P1.dip)
      oracle.g1.dip <- graph.adjacency(oracle.A1.dip, "undirected")
      oracle.DIP.result[[jj]] <- list( g1.dip = oracle.g1.dip,X1.dip = oracle.X1.dip)
      
    }
  }
  
  
  
  ##### naive Laplace method
  X.tilde <- X.trans
  
  X1.hat <- X.tilde[idx, ,drop=FALSE]
  
  Laplace.result <- list()
  for(jj in 1:L){
    cat(paste("Calling Laplace with ε=", eps[jj], "\n", sep=""))
    X1.Lap <- Add.Laplace(X = X1.hat, eps = eps[jj])
    
    theta1.Lap <- X1.Lap%*%t(X1.Lap)
    P1.Lap <- theta1.Lap
    P1.Lap[theta1.Lap>(1-1e-5)] <- 1-1e-5
    P1.Lap[theta1.Lap< 1e-5] <- 1e-5
    
    
    A1.Lap <- gen.A.from.P(P1.Lap)
    
    g1 <- graph.adjacency(A11,"undirected")
    g1.Lap <- graph.adjacency(A1.Lap,"undirected")
    Laplace.result[[jj]] <- list(g1.Lap = g1.Lap, X1.Lap=X1.Lap)
    
  }
  return(list(non.private.result=non.private.result,DIP.result=DIP.result,Laplace.result=Laplace.result,eps=eps,oracle.DIP.result=oracle.DIP.result))
  
}





get.v <- function(g){
  deg_vec <- degree(g)
  twostar_counts <- choose(deg_vec, 2)
  return(twostar_counts)
}
