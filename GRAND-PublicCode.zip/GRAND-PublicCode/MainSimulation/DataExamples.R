
library(randnet)
library(GRANDpriv)
library(igraph)
library(HCD)

get.v <- function(g) choose(degree(g), 2)

load("DataForGNC-Plot-Combined.Rda")

n <- nrow(A)
n

summary(rowSums(A))

proc <- k.core(A,2)

A <- proc$A
n <- nrow(A)
n

set.seed(101)
release.index <- sample(n,size=floor(n/2))

A11 <- A[release.index,release.index]


result <- GRAND.privatize(A=as.matrix(A),K=4,idx=release.index,eps=c(1,2,5,10),model="LSM",niter = 5000)

g1.true <- graph.adjacency(A11,"undirected")

g1.dip <- result$GRAND.result[[1]]$g1.grand

g1.lap <- result$Laplace.result[[1]]$g1.Lap

part.estimate <- LSM.PGD(as.matrix(A11), 4, niter = 5000)
alpha1.hat <- matrix(part.estimate$alpha,nrow=nrow(A11))
Z1.hat <- matrix(part.estimate$Z,nrow=nrow(A11))
theta1.hat <- alpha1.hat%*%t(rep(1, nrow(A11))) + rep(1, nrow(A11))%*%t(alpha1.hat) + Z1.hat%*%t(Z1.hat)
P1.hat <- 1 / (1 + exp(-theta1.hat))
A1.hat <- gen.A.from.P(P1.hat)
g1.hat <- graph.adjacency(A1.hat, "undirected")



colors <- c(
  True = "#000000",
  GRAND = "#FF7F0E",
  Laplace = "#2CA02C",
  Hat = "#1F77B4"
)



pdf("Ji-Statistician-Degree.pdf",height=5,width=5)
deg.true <- log(1+degree(graph = g1.true))
deg.dip <- log(1+degree(graph = g1.dip))
deg.lap <- log(1+degree(graph = g1.lap))
deg.hat <- log(1+degree(graph = g1.hat))

plot(density(deg.true,bw = 1.3),xlim=c(-4,10),col=colors[1],ylim=c(0,0.43),lwd=2,cex.lab=1.4,main="",xlab="Degree (log)")
lines(density(deg.dip,bw = 1.3),col=colors[2],lwd=2)
lines(density(deg.lap,bw = 1.3),col=colors[3],lwd=2)
lines(density(deg.hat,bw = 1.3),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()




pdf("Ji-Statistician-2star.pdf",height=5,width=5)
vs.true <- log(1+get.v(g1.true))
vs.dip <- log(1+get.v(g1.dip))
vs.lap <- log(1+get.v(g1.lap))
vs.hat <- log(1+get.v(g1.hat))

plot(density(vs.true,bw = 1.3),xlim=c(-4,14),col=colors[1],ylim=c(0,0.43),lwd=2,cex.lab=1.4,main="",xlab="V-shape Count (log)")
lines(density(vs.dip,bw = 1.3),col=colors[2],lwd=2)
lines(density(vs.lap,bw = 1.3),col=colors[3],lwd=2)
lines(density(vs.hat,bw = 1.3),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])
dev.off()





pdf("Ji-Statistician-Triangle.pdf",height=5,width=5)
tri.true <- log(1+count_triangles(g1.true))
tri.dip <- log(1+count_triangles(g1.dip))
tri.lap <- log(1+count_triangles(g1.lap))
tri.hat <- log(1+count_triangles(g1.hat))


plot(density(tri.true,bw = 1.3),xlim=c(-3,14),col=colors[1],ylim=c(0,0.43),lwd=2,cex.lab=1.4,main="",xlab="Triangle Count (log)")
lines(density(tri.dip,bw = 1.3),col=colors[2],lwd=2)
lines(density(tri.lap,bw = 1.3),col=colors[3],lwd=2)
lines(density(tri.hat,bw = 1.3),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()



pdf("Ji-Statistician-Eigen.pdf",height=5,width=5)
eigen.true <- eigen_centrality(g1.true)$vector
eigen.dip <- eigen_centrality(g1.dip)$vector
eigen.lap <- eigen_centrality(g1.lap)$vector
eigen.hat <- eigen_centrality(g1.hat)$vector


all.deg <- c(eigen.true, eigen.dip,eigen.lap)
summary(all.deg)
plot(density(eigen.true,bw = 0.18),xlim=c(-0.5,1.6),col=colors[1],ylim=c(0,3),lwd=2,cex.lab=1.4,main="",xlab="Eigen Centrality")
lines(density(eigen.dip,bw = 0.18),col=colors[2],lwd=2)
lines(density(eigen.lap,bw = 0.18),col=colors[3],lwd=2)
lines(density(eigen.hat,bw = 0.18),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()


pdf("Ji-Statistician-Harmonic.pdf",height=5,width=5)
harmonic.true <- harmonic_centrality(g1.true)
harmonic.dip <- harmonic_centrality(g1.dip)
harmonic.lap <- harmonic_centrality(g1.lap)
harmonic.hat <- harmonic_centrality(g1.hat)

all.deg <- c(harmonic.true, harmonic.dip,harmonic.lap)


summary(all.deg)
plot(density(harmonic.true,bw = 4),xlim=c(-10,210),col=colors[1],ylim=c(0,0.15),lwd=2,cex.lab=1.4,main="",xlab="Harmonic Closeness")
lines(density(harmonic.dip,bw = 4),col=colors[2],lwd=2)
lines(density(harmonic.lap,bw = 4),col=colors[3],lwd=2)
lines(density(harmonic.hat,bw = 4),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])
dev.off()






dt <- scan("Caltech36.mtx",what="",sep="\n")

length(dt)

head(dt)
dt <- dt[-(1:2)]

tail(dt)
edge.mat <- matrix(as.numeric(unlist(strsplit(dt," "))),ncol=2,byrow=TRUE)
dim(edge.mat)

head(edge.mat)

g <- graph.data.frame(data.frame(edge.mat),directed = FALSE)

length(V(g))



A <- as.matrix(get.adjacency(g,"both"))


proc <- k.core(A,2)

A <- proc$A




n <- nrow(A)
n

set.seed(101)
release.index <- sample(n,size=floor(n/2))

A11 <- A[release.index,release.index]


result <- GRAND.privatize(A=as.matrix(A),K=6,idx=release.index,eps=c(1,2,5,10),model="LSM",niter = 5000)

part.estimate <- LSM.PGD(as.matrix(A11), 6, niter = 5000)
alpha1.hat <- matrix(part.estimate$alpha,nrow=nrow(A11))
Z1.hat <- matrix(part.estimate$Z,nrow=nrow(A11))
theta1.hat <- alpha1.hat%*%t(rep(1, nrow(A11))) + rep(1, nrow(A11))%*%t(alpha1.hat) + Z1.hat%*%t(Z1.hat)
P1.hat <- 1 / (1 + exp(-theta1.hat))
A1.hat <- gen.A.from.P(P1.hat)
g1.hat <- graph.adjacency(A1.hat, "undirected")


g1.true<- graph.adjacency(A11,"undirected")



g1.dip <- result$GRAND.result[[1]]$g1.grand

g1.lap <- result$Laplace.result[[1]]$g1.Lap




colors <- c(
  True = "#000000",
  GRAND = "#FF7F0E",
  Laplace = "#2CA02C",
  Hat = "#1F77B4"
)



pdf("Caltech-Degree.pdf",height=5,width=5)
deg.true <- log(1+degree(graph = g1.true))
deg.dip <- log(1+degree(graph = g1.dip))
deg.lap <- log(1+degree(graph = g1.lap))
deg.hat <- log(1+degree(graph = g1.hat))

plot(density(deg.true,bw = 1),xlim=c(-3,9),col=colors[1],ylim=c(0,0.4),lwd=2,cex.lab=1.4,main="",xlab="Degree (log)")
lines(density(deg.dip,bw = 1),col=colors[2],lwd=2)
lines(density(deg.lap,bw = 1),col=colors[3],lwd=2)
lines(density(deg.hat,bw = 1.2),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()



pdf("Caltech-2star.pdf",height=5,width=5)
vs.true <- log(1+get.v(g1.true))
vs.dip <- log(1+get.v(g1.dip))
vs.lap <- log(1+get.v(g1.lap))
vs.hat <- log(1+get.v(g1.hat))

plot(density(vs.true,bw = 1.8),xlim=c(-4,15),col=colors[1],ylim=c(0,0.3),lwd=2,cex.lab=1.4,main="",xlab="V-shape Count (log)")
lines(density(vs.dip,bw = 1.8),col=colors[2],lwd=2)
lines(density(vs.lap,bw = 1.8),col=colors[3],lwd=2)
lines(density(vs.hat,bw = 1.8),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])
dev.off()



pdf("Caltech-Triangle.pdf",height=5,width=5)
tri.true <- log(1+count_triangles(g1.true))
tri.dip <- log(1+count_triangles(g1.dip))
tri.lap <- log(1+count_triangles(g1.lap))
tri.hat <- log(1+count_triangles(g1.hat))


plot(density(tri.true,bw = 1.8),xlim=c(-3,14),col=colors[1],ylim=c(0,0.3),lwd=2,cex.lab=1.4,main="",xlab="Triangle Count (log)")
lines(density(tri.dip,bw = 1.8),col=colors[2],lwd=2)
lines(density(tri.lap,bw = 1.8),col=colors[3],lwd=2)
lines(density(tri.hat,bw = 1.8),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()





pdf("Caltech-Eigen.pdf",height=5,width=5)
eigen.true <- eigen_centrality(g1.true)$vector
eigen.dip <- eigen_centrality(g1.dip)$vector
eigen.lap <- eigen_centrality(g1.lap)$vector
eigen.hat <- eigen_centrality(g1.hat)$vector


all.deg <- c(eigen.true, eigen.dip,eigen.lap)
summary(all.deg)
plot(density(eigen.true,bw = 0.18),xlim=c(-0.5,1.6),col=colors[1],ylim=c(0,2.5),lwd=2,cex.lab=1.4,main="",xlab="Eigen Centrality")
lines(density(eigen.dip,bw = 0.18),col=colors[2],lwd=2)
lines(density(eigen.lap,bw = 0.18),col=colors[3],lwd=2)
lines(density(eigen.hat,bw = 0.18),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()




pdf("Caltech-Harmonic.pdf",height=5,width=5)
harmonic.true <- harmonic_centrality(g1.true)
harmonic.dip <- harmonic_centrality(g1.dip)
harmonic.lap <- harmonic_centrality(g1.lap)
harmonic.hat <- harmonic_centrality(g1.hat)
#plot(density(harmonic.true,bw=1))

all.deg <- c(harmonic.true, harmonic.dip,harmonic.lap)


summary(all.deg)
plot(density(harmonic.true,bw = 10),xlim=c(0,300),col=colors[1],ylim=c(0,0.045),lwd=2,cex.lab=1.4,main="",xlab="Harmonic Closeness")
lines(density(harmonic.dip,bw = 10),col=colors[2],lwd=2)
lines(density(harmonic.lap,bw = 10),col=colors[3],lwd=2)
lines(density(harmonic.hat,bw = 10),col=colors[4],lwd=2)
legend("topleft", legend = c("True", "GRAND", "Laplace","Hat (non-private)"),
       lwd=2,lty=1,col=colors[1:4])

dev.off()
