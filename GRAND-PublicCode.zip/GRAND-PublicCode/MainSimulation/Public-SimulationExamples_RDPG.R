custom_lib_path <- "~/Rlibs"
# Add the custom library path to the current R session
.libPaths(custom_lib_path)
library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)


rep.m <- 100

N.seq <- c(2000,4000,6000,8000)
rho.seq <- c(0.025,0.05,0.1)
rank.seq <- c(3,6)

dir.create("RDPG_Results", showWarnings = FALSE)

for(I1 in 1:length(N.seq)){
  for(I2 in 1:length(rho.seq)){
    for(I3 in 1:length(rank.seq)){
      N.val <- N.seq[I1]
      rho.val <- rho.seq[I2]
      rank.val <- rank.seq[I3]
      
      foreach(i = 1:rep.m,.packages=c("GRANDpriv","randnet"),.errorhandling ="pass")%dopar%{
        m <- N.val / 2
        n <- N.val / 2
        dt <- RDPG.Gen(n = m+n, K = rank.val, directed = FALSE, avg.d = rho.val*(m+n))
        A <- dt$A
        idx <- 1:n
        test1 <- GRAND.privatize(A,rank.val,idx,eps=c(1,2,5,10),model="RDPG")
        res <- GRAND.evaluate(test1)
        
        filename <- paste(
          "./RDPG_Results/RDPG_N=", N.val,
          "_Rho=", rho.val,
          "_Rank=", rank.val,
          "_Index=", i,
          ".Rda",
          sep = ""
        )
        save(res,file=filename)
        gc()
      }
      
      
      
    }
  }
}
