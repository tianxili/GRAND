
result_dir <- "Misspecification"
out_dir <- file.path(result_dir, "plots", "Graphon2")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

fix_N <- 4000
fix_Rho <- 0.05
fix_Ratio <- 50
use_log_y <- TRUE

stat_levels <- c(
  "Node Degree",
  "V-Shape Count",
  "Triangle Count",
  "Eigen Centrality",
  "Harmonic Centrality"
)
stat_labels <- c(
  "Node Degree" = "Node Degree",
  "V-Shape Count" = "V-shape Count",
  "Triangle Count" = "Triangle Count",
  "Eigen Centrality" = "Eigen Centrality",
  "Harmonic Centrality" = "Harmonic Centrality"
)

method_cols <- c("Hat", "GRAND", "Laplace")
method_levels <- method_cols
method_labels <- c(
  Hat = "Hat (non-private)",
  GRAND = "GRAND",
  Laplace = "Laplace"
)
method_palette <- c(
  Hat = "#1F77B4",
  GRAND = "#FF7F0E",
  Laplace = "#2CA02C"
)
method_shape <- c(
  Hat = 16,
  GRAND = 17,
  Laplace = 15
)

parse_meta <- function(path) {
  x <- basename(path)
  m <- regexec(
    "^Gen=(Graphon2)_Fit=(LSM|RDPG)_N=([0-9]+)_Rho=([0-9.]+)_Index=([0-9]+)_Ratio=([0-9.]+)\\.Rda$",
    x
  )
  hit <- regmatches(x, m)[[1]]
  if (length(hit) == 0) return(NULL)

  data.frame(
    file = x,
    Gen = hit[2],
    Fit = hit[3],
    N = as.integer(hit[4]),
    Rho = as.numeric(hit[5]),
    Index = as.integer(hit[6]),
    Ratio = as.numeric(hit[7]),
    stringsAsFactors = FALSE
  )
}

read_one <- function(path) {
  meta <- parse_meta(path)
  if (is.null(meta)) return(NULL)

  e <- new.env(parent = emptyenv())
  load(path, envir = e)
  if (!exists("res", envir = e)) {
    stop("File has no object named res: ", basename(path))
  }

  res <- get("res", envir = e)
  missing_cols <- setdiff(c("stat", "eps", method_cols), names(res))
  if (length(missing_cols) > 0) {
    stop("Missing columns in ", basename(path), ": ", paste(missing_cols, collapse = ", "))
  }

  rows <- list()
  k <- 1
  for (method in method_cols) {
    rows[[k]] <- data.frame(
      meta[rep(1, nrow(res)), ],
      stat = res$stat,
      eps = as.numeric(res$eps),
      method = method,
      W1 = as.numeric(res[[method]]),
      row.names = NULL,
      stringsAsFactors = FALSE
    )
    k <- k + 1
  }
  do.call(rbind, rows)
}

files <- list.files(
  result_dir,
  pattern = "^Gen=Graphon2_Fit=(LSM|RDPG)_N=[0-9]+_Rho=[0-9.]+_Index=[0-9]+_Ratio=[0-9.]+\\.Rda$",
  full.names = TRUE
)
if (length(files) == 0) {
  stop("No matching Gen=Graphon2, Fit=LSM/RDPG result files found.")
}

records <- Filter(Negate(is.null), lapply(files, read_one))
if (length(records) == 0) {
  stop("No valid records were read from the matching result files.")
}
all_w1 <- do.call(rbind, records)

if (!is.na(fix_N)) all_w1 <- all_w1[all_w1$N == fix_N, ]
if (!is.na(fix_Rho)) all_w1 <- all_w1[all_w1$Rho == fix_Rho, ]
if (!is.na(fix_Ratio)) all_w1 <- all_w1[all_w1$Ratio == fix_Ratio, ]

if (nrow(all_w1) == 0) {
  stop("No records left after filtering. Check fix_N/fix_Rho/fix_Ratio.")
}

fit_indices <- lapply(split(all_w1$Index, all_w1$Fit), unique)
required_fits <- c("LSM", "RDPG")
if (!all(required_fits %in% names(fit_indices))) {
  stop("Both Fit=LSM and Fit=RDPG are required after filtering.")
}
common_indices <- Reduce(intersect, fit_indices[required_fits])
if (length(common_indices) == 0) {
  stop("Fit=LSM and Fit=RDPG have no common Index values after filtering.")
}
all_w1 <- all_w1[all_w1$Index %in% common_indices, ]
unknown_stats <- setdiff(unique(as.character(all_w1$stat)), stat_levels)
if (length(unknown_stats) > 0) {
  stop("Unexpected stat values: ", paste(unknown_stats, collapse = ", "))
}
all_w1$stat <- factor(all_w1$stat, levels = stat_levels)
all_w1$method <- factor(all_w1$method, levels = method_levels)
all_w1$eps <- factor(all_w1$eps, levels = sort(unique(as.numeric(all_w1$eps))))

write.csv(all_w1, file.path(out_dir, "all_w1_long_by_eps_Graphon2.csv"), row.names = FALSE)

summary_w1 <- aggregate(
  W1 ~ Gen + Fit + N + Rho + Ratio + stat + eps + method,
  all_w1,
  function(z) {
    c(
      mean = mean(z, na.rm = TRUE),
      sd = sd(z, na.rm = TRUE),
      se = sd(z, na.rm = TRUE) / sqrt(sum(!is.na(z))),
      n = sum(!is.na(z))
    )
  }
)
summary_w1 <- do.call(data.frame, summary_w1)
names(summary_w1)[names(summary_w1) == "W1.mean"] <- "mean"
names(summary_w1)[names(summary_w1) == "W1.sd"] <- "sd"
names(summary_w1)[names(summary_w1) == "W1.se"] <- "se"
names(summary_w1)[names(summary_w1) == "W1.n"] <- "n"
summary_w1$method <- factor(summary_w1$method, levels = method_levels)
summary_w1$stat <- factor(summary_w1$stat, levels = stat_levels)
summary_w1$eps <- factor(
  summary_w1$eps,
  levels = sort(unique(as.numeric(as.character(summary_w1$eps))))
)
fit_levels <- c("LSM", "RDPG")
summary_w1$Fit <- factor(summary_w1$Fit, levels = fit_levels)
min_positive_mean <- min(summary_w1$mean[summary_w1$mean > 0], na.rm = TRUE)
summary_w1$lower <- if (use_log_y) {
  pmax(summary_w1$mean - summary_w1$se, min_positive_mean * 0.5)
} else {
  pmax(summary_w1$mean - summary_w1$se, 0)
}
summary_w1$upper <- summary_w1$mean + summary_w1$se

write.csv(summary_w1, file.path(out_dir, "w1_summary_by_eps_Graphon2.csv"), row.names = FALSE)

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  stop("Please install ggplot2 first: install.packages('ggplot2')")
}
if (!requireNamespace("patchwork", quietly = TRUE)) {
  stop("Please install patchwork first: install.packages('patchwork')")
}

library(ggplot2)
library(patchwork)

publication_theme <- function(base_size = 11.3) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(face = "plain"),
      axis.title = element_text(face = "plain", size = 12.4),
      axis.text = element_text(face = "plain", color = "grey15", size = 9.8),
      axis.line = element_blank(),
      axis.ticks = element_line(color = "grey25", linewidth = 0.35),
      panel.border = element_rect(color = "grey25", fill = NA, linewidth = 0.5),
      panel.grid.major = element_line(color = "grey88", linewidth = 0.25),
      panel.grid.minor = element_blank(),
      strip.background = element_rect(fill = "grey96", color = "grey25", linewidth = 0.35),
      strip.text = element_text(face = "plain", color = "grey10", size = 11),
      legend.position = "bottom",
      legend.title = element_text(face = "plain", size = 11.3, margin = margin(r = 14)),
      legend.text = element_text(face = "plain", size = 11.3),
      legend.key.width = grid::unit(1.6, "lines"),
      legend.background = element_blank(),
      plot.margin = margin(8, 10, 8, 8),
      panel.spacing.x = grid::unit(0.9, "lines"),
      panel.spacing.y = grid::unit(0.75, "lines")
    )
}

y_axis_label <- if (use_log_y) "Wasserstein Distance (log)" else "Wasserstein Distance"
y_scale <- function() {
  if (use_log_y) {
    scale_y_log10(expand = expansion(mult = c(0.03, 0.08)))
  } else {
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.08)))
  }
}
eps_breaks <- c(1, 2, 5, 10)
fit_linetype <- c(LSM = "dashed", RDPG = "solid")

pd <- position_dodge(width = 0.18)
p <- ggplot(
  summary_w1,
  aes(
    x = as.numeric(as.character(eps)),
    y = mean,
    color = method,
    shape = method,
    linetype = Fit,
    group = interaction(Fit, method)
  )
) +
  geom_errorbar(
    aes(ymin = lower, ymax = upper),
    width = 0.24,
    linewidth = 0.58,
    alpha = 0.68,
    position = pd,
    show.legend = FALSE
  ) +
  geom_line(linewidth = 0.78, alpha = 0.96, position = pd) +
  geom_point(size = 1.9, stroke = 0.25, alpha = 0.98, position = pd) +
  facet_wrap(
    ~ stat,
    scales = "free_y",
    nrow = 2,
    labeller = as_labeller(stat_labels, default = label_value)
  ) +
  scale_color_manual(
    name = "varepsilon", values = method_palette,
    breaks = method_levels, limits = method_levels,
    labels = method_labels, drop = FALSE
  ) +
  scale_shape_manual(
    name = "varepsilon", values = method_shape,
    breaks = method_levels, limits = method_levels,
    labels = method_labels, drop = FALSE
  ) +
  scale_linetype_manual(
    name = NULL, values = fit_linetype,
    breaks = fit_levels, limits = fit_levels, drop = FALSE
  ) +
  scale_x_continuous(
    breaks = eps_breaks,
    limits = range(eps_breaks) + c(-0.5, 0.5)
  ) +
  y_scale() +
  labs(x = NULL, y = y_axis_label) +
  guides(
    color = guide_legend(nrow = 1, order = 1),
    shape = guide_legend(nrow = 1, order = 1),
    linetype = guide_legend(nrow = 1, order = 2)
  ) +
  publication_theme(base_size = 11.3) +
  theme(
    strip.text = element_text(face = "plain", size = 11),
    legend.box = "horizontal",
    legend.box.just = "center",
    axis.title.y = element_text(face = "plain", size = 12.4, margin = margin(r = 5))
  )

legend_grob <- gtable::gtable_filter(ggplotGrob(p), "guide-box-bottom")
plist <- lapply(stat_levels, function(s) {
  (p + droplevels(summary_w1[
    as.character(summary_w1$stat) == s, , drop = FALSE
  ])) +
    theme(legend.position = "none")
})
layout_design <- "AABBCC\n#DDEE#\nGGGGGG"
p <- wrap_plots(
  A = plist[[1]], B = plist[[2]], C = plist[[3]],
  D = plist[[4]], E = plist[[5]],
  G = wrap_elements(full = legend_grob),
  design = layout_design,
  axes = "keep",
  axis_titles = "collect",
  heights = c(1, 1, 0.10)
)

png_file <- file.path(out_dir, "w1_vs_eps_Graphon2_all_panels.png")
png_tmp <- tempfile(fileext = ".png")
ggsave(png_tmp, p, width = 10.8, height = 6.6, dpi = 600)
if (!file.copy(png_tmp, png_file, overwrite = TRUE)) {
  stop("Could not copy PNG output to: ", png_file)
}
unlink(png_tmp)
ggsave(
  file.path(out_dir, "w1_vs_eps_Graphon2_all_panels.pdf"),
  p,
  width = 10.8,
  height = 6.6,
  device = cairo_pdf
)

message("Done. Outputs written to: ", normalizePath(out_dir))
