custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)

rep.m <- 100

N.seq <- c(4000)
rho.seq <- c(0.05)
ratio.seq <- c(50)

dir.create("Misspecification", showWarnings = FALSE)

Graphon2.Graphon <- function(u, v) {
  (u^2 + v^2) / 3 * cos(1 / (u^2 + v^2)) + 0.15
}

Graphon2.Gen <- function(n, avg.d = NULL) {
  u <- runif(n)
  P <- outer(u, u, Graphon2.Graphon)

  if (!is.null(avg.d)) {
    P <- P * (avg.d / mean(rowSums(P)))
    P[P > 1] <- 1
  }

  diag(P) <- 0
  upper.index <- which(upper.tri(P))
  upper.p <- P[upper.index]
  upper.u <- runif(length(upper.p))
  upper.A <- rep(0, length(upper.p))
  upper.A[upper.u < upper.p] <- 1

  A <- matrix(0, n, n)
  A[upper.index] <- upper.A
  A <- A + t(A)
  diag(A) <- 0

  list(A = A, u = u)
}

for (I1 in 1:length(N.seq)) {
  for (I2 in 1:length(rho.seq)) {
    for (I3 in 1:length(ratio.seq)) {
      N.val <- N.seq[I1]
      rho.val <- rho.seq[I2]
      ratio.val <- ratio.seq[I3]

      foreach(
        i = 1:rep.m,
        .packages = c("randnet", "GRANDpriv"),
        .errorhandling = "pass"
      ) %dopar% {
        for (fit.model in c("LSM", "RDPG")) {                
          filename <- paste(
            "./Misspecification/Gen=Graphon2_Fit=", fit.model,
            "_N=", N.val,
            "_Rho=", rho.val,
            "_Index=", i,
            "_Ratio=", ratio.val,
            ".Rda",
            sep = ""
          )

          if (!file.exists(filename)) {
            m <- N.val * ratio.val / 100
            n <- N.val * (1 - ratio.val / 100)
            dt <- Graphon2.Gen(n = m + n, avg.d = rho.val * (m + n))
            A <- dt$A
            idx <- 1:n
            rdpg.rank <- ECV.Rank(A[-idx, -idx], 10, mode = "undirected")$sse.rank
            fit.rank <- if (fit.model == "LSM") 1 else rdpg.rank
            test <- GRAND.privatize(A, fit.rank, idx, eps = c(1, 2, 5, 10), model = fit.model)
            res <- GRAND.evaluate(test)
                
            save(res, file = filename)
            gc()
          }
            
          NULL
        }          
      }
    }
  }
}
