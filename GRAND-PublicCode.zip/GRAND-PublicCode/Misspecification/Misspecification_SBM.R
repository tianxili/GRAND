custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)

rep.m <- 100

N.seq <- c(4000)
rho.seq <- c(0.05)
ratio.seq <- c(50)

dir.create("Misspecification", showWarnings = FALSE)

SBM.Graphon <- function(x, y, B) {
  K.block <- nrow(B)
  x.block <- pmin(floor(x * K.block) + 1, K.block)
  y.block <- pmin(floor(y * K.block) + 1, K.block)

  B[cbind(x.block, y.block)]
}

SBM.Gen <- function(n, K.block = 5, avg.d = NULL, assort.ratio = 4) {
  u <- runif(n)
  z <- pmin(floor(u * K.block) + 1, K.block)

  B.base <- matrix(1, K.block, K.block)
  diag(B.base) <- assort.ratio

  expected.degree <- rowSums(B.base[z, z]) - diag(B.base)[z]
  scale <- avg.d / mean(expected.degree)
  B <- B.base * scale
  B[B > 1] <- 1

  A <- matrix(0, n, n)
  upper.index <- which(upper.tri(A), arr.ind = TRUE)
  upper.rows <- upper.index[, 1]
  upper.cols <- upper.index[, 2]
  upper.p <- SBM.Graphon(u[upper.rows], u[upper.cols], B)
  upper.u <- runif(length(upper.p))
  upper.A <- rep(0, length(upper.p))
  upper.A[upper.u < upper.p] <- 1

  A[upper.index] <- upper.A
  A <- A + t(A)
  diag(A) <- 0

  list(A = A, u = u)
}

for (I1 in 1:length(N.seq)) {
  for (I2 in 1:length(rho.seq)) {
    for (I3 in 1:length(ratio.seq)) {
      N.val <- N.seq[I1]
      rho.val <- rho.seq[I2]
      ratio.val <- ratio.seq[I3]

      foreach(
        i = 1:rep.m,
        .packages = c("randnet", "GRANDpriv"),
        .errorhandling = "pass"
      ) %dopar% {
        for (fit.model in c("LSM", "RDPG")) {                
          filename <- paste(
            "./Misspecification/Gen=SBM_Fit=", fit.model,
            "_N=", N.val,
            "_Rho=", rho.val,
            "_Index=", i,
            "_Ratio=", ratio.val,
            ".Rda",
            sep = ""
          )

          if (!file.exists(filename)) {
            m <- N.val * ratio.val / 100
            n <- N.val * (1 - ratio.val / 100)
            dt <- SBM.Gen(n = m + n, K.block = 5, avg.d = rho.val * (m + n))
            A <- dt$A
            idx <- 1:n
            rdpg.rank <- ECV.Rank(A[-idx, -idx], 10, mode = "undirected")$sse.rank
            fit.rank <- if (fit.model == "LSM") 1 else rdpg.rank
            test <- GRAND.privatize(A, fit.rank, idx, eps = c(1, 2, 5, 10), model = fit.model)
            res <- GRAND.evaluate(test)
                
            save(res, file = filename)
            gc()
          }
            
          NULL
        }          
      }
    }
  }
}
