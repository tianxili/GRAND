custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)

rep.m <- 100

N.seq <- c(4000)
rho.seq <- c(0.05)
rank.seq <- c(3)
ratio.seq <- c(50)

dir.create("Misspecification", showWarnings = FALSE)

for (I1 in 1:length(N.seq)) {
  for (I2 in 1:length(rho.seq)) {
    for (I3 in 1:length(rank.seq)) {
      for (I4 in 1:length(ratio.seq)) {
        N.val <- N.seq[I1]
        rho.val <- rho.seq[I2]
        gen.rank <- rank.seq[I3]
        ratio.val <- ratio.seq[I4]

        foreach(
          i = 1:rep.m,
          .packages = c("randnet", "GRANDpriv"),
          .errorhandling = "pass"
        ) %dopar% {
          for (fit.model in c("LSM", "RDPG")) {                
            filename <- paste(
              "./Misspecification/Gen=LSM_Fit=", fit.model,
              "_N=", N.val,
              "_Rho=", rho.val,
              "_Rank=", gen.rank,
              "_Index=", i,
              "_Ratio=", ratio.val,
              ".Rda",
              sep = ""
            )

            if (!file.exists(filename)) {
              m <- N.val * ratio.val / 100
              n <- N.val * (1 - ratio.val / 100)
              dt <- LSM.Gen(n = m + n, k = gen.rank, K = 5, avg.d = rho.val * (m + n))
              A <- dt$A
              idx <- 1:n
              rdpg.rank <- ECV.Rank(A[-idx, -idx], 10, mode = "undirected")$sse.rank
              fit.rank <- if (fit.model == "LSM") gen.rank else rdpg.rank
              test <- GRAND.privatize(A, fit.rank, idx, eps = c(1, 2, 5, 10), model = fit.model)
              res <- GRAND.evaluate(test)
                
              save(res, file = filename)
              gc()
            }
            
            NULL
          }          
        }
      }
    }
  }
}
