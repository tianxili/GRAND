library(ggplot2)

blues <- c(
  "#F7FBFF", "#DEEBF7", "#C6DBEF", "#9ECAE1", "#6BAED6",
  "#4292C6", "#2171B5", "#08519C"
)

Graphon1.Graphon <- function(u, v) {
  1 - 1 / (1 + exp(15 * (0.8 * abs(u - v))^(4 / 5) - 0.1))
}

out_dir <- file.path("Misspecification", "plots", "Graphon_Heatmaps")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

grid_values <- seq(0, 1, length.out = 301)
grid <- expand.grid(u = grid_values, v = grid_values)
plot_data <- data.frame(
  u = grid$u,
  v = grid$v,
  value = Graphon1.Graphon(grid$u, grid$v)
)

p <- ggplot(plot_data, aes(x = u, y = v, fill = value)) +
  geom_raster() +
  coord_equal(expand = FALSE) +
  scale_x_continuous(expand = expansion(mult = 0)) +
  scale_y_reverse(expand = expansion(mult = 0)) +
  scale_fill_gradientn(
    limits = c(0, 1),
    colours = blues,
    values = seq(0, 1, length.out = length(blues)),
    space = "Lab",
    guide = "none"
  ) +
  theme_void(base_size = 11) +
  theme(
    text = element_text(face = "plain", colour = "black"),
    plot.margin = margin(0, 0, 0, 0)
  )

ggsave(
  file.path(out_dir, "Graphon1_Heatmap.pdf"),
  p,
  width = 3.1,
  height = 3.1,
  device = cairo_pdf
)

png_file <- file.path(out_dir, "Graphon1_Heatmap.png")
png_tmp <- tempfile(fileext = ".png")
ggsave(png_tmp, p, width = 3.1, height = 3.1, dpi = 600)
if (!file.copy(png_tmp, png_file, overwrite = TRUE)) {
  stop("Could not copy PNG output to: ", png_file)
}
unlink(png_tmp)
