custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(GRANDpriv)
library(doParallel)

registerDoParallel(10)

## Membership-inference attack on the hold-out set. Each replicate generates one
## network, applies GRAND to it, and scores the planted candidate nodes against
## the released latent positions under the two versions compared in the paper:
## the un-privatized positions X1.hat and the GRAND output X1.grand.

N.val <- 4000
rho.val <- 0.05
rank.val <- 3
eps.val <- 1

ratio.seq <- c(5, 10, 25, 50)             # 100 * m / N
rep.m <- 400                              # replicates summarized per setting

## The hold-out model fitting in Step 3 does not always converge at the smallest
## hold-out sizes, so more draws are attempted than the rep.m replicates that are
## summarized; Membership_Attack_Table.R uses the first rep.m completed ones.
attempt.seq <- c(1680, 452, 420, 420)

dir.create("Membership", showWarnings = FALSE)

## Attack score of one candidate node: the attained mean deviance of the
## node-wise estimation objective of GRAND, with the roles of the two node sets
## exchanged, holding the released latent positions fixed and fitting the
## candidate.
##   u: length-n 0/1 edge profile of the candidate to the released nodes.
##   V: n x (rank + 1) released latent positions, column 1 the intercept alpha.
node.deviance <- function(u, V) {
  Z <- V[, -1, drop = FALSE]
  fit <- suppressWarnings(
    glm(u ~ Z, family = binomial(), offset = V[, 1], maxit = 1000)
  )
  fit$deviance / (2 * length(u))
}

for (I1 in 1:length(ratio.seq)) {
  ratio.val <- ratio.seq[I1]
  attempt.val <- attempt.seq[I1]

  foreach(
    i = 1:attempt.val,
    .packages = c("randnet", "GRANDpriv"),
    .errorhandling = "pass"
  ) %dopar% {
    filename <- paste(
      "./Membership/Membership_N=", N.val,
      "_Rho=", rho.val,
      "_Rank=", rank.val,
      "_Index=", i,
      "_Ratio=", ratio.val,
      ".Rda",
      sep = ""
    )

    if (!file.exists(filename)) {
      m <- N.val * ratio.val / 100
      n <- N.val - m
      k <- min(50, floor(m / 20))

      ## All nodes are drawn together from the same latent distribution: n
      ## released nodes, m - k ordinary hold-out nodes, and 2k candidates.
      pool <- n + (m - k) + 2 * k
      dt <- LSM.Gen(pool, rank.val, 5, avg.d = rho.val * pool)

      rel.index <- 1:n
      core.index <- n + (1:(m - k))
      can.index <- n + (m - k) + (1:(2 * k))

      ## k candidates join the hold-out set, k are excluded from the data.
      in.index <- sort(sample(can.index, k))
      out.index <- setdiff(can.index, in.index)

      ## The analysed network has n released and exactly m hold-out nodes.
      net.index <- c(rel.index, core.index, in.index)
      A <- dt$A[net.index, net.index]

      ## Edge profiles to the released nodes, read from the same generated
      ## network for selected and excluded candidates alike, so the two groups
      ## differ only in whether GRAND used them.
      U <- dt$A[rel.index, c(in.index, out.index), drop = FALSE]

      test <- GRAND.privatize(A, rank.val, idx = rel.index, eps = eps.val,
                              model = "LSM", niter = 500, rho = 0.05,
                              verbose = FALSE)

      V.nonprivate <- test$non.private.result$X1.hat
      V.grand <- test$GRAND.result[[1]]$X1.grand

      res <- data.frame(
        ratio = ratio.val,
        index = i,
        label = rep(c("IN", "OUT"), each = k),
        score.nonprivate = apply(U, 2, node.deviance, V = V.nonprivate),
        score.grand = apply(U, 2, node.deviance, V = V.grand)
      )

      save(res, file = filename)
      gc()
    }

    NULL
  }
}
