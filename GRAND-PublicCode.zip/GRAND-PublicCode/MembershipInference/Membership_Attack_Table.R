custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

## Summarizes the saved attack scores from Membership_Attack.R into the table of
## membership-inference advantages reported in the paper.

N.val <- 4000
rho.val <- 0.05
rank.val <- 3

ratio.seq <- c(5, 10, 25, 50)             # 100 * m / N
rep.m <- 400                              # replicates summarized per setting
B <- 20000                                # label reassignments

set.seed(90260831)

## Attack advantage sup_t { F_in(t) - F_out(t) } and its permutation p-value.
## Under the hypothesis that a node's score would have been the same in either
## group, the scores within a replicate are fixed and only the labels are
## random, so the reference distribution reassigns the labels uniformly within
## each replicate, preserving the group sizes.
attack.advantage <- function(score, is.in, repid, B) {
  o <- order(score)
  s <- score[o]
  lab <- is.in[o]
  rp <- as.integer(factor(repid[o]))

  last <- c(s[-length(s)] != s[-1], TRUE)
  n <- length(lab)
  n.in <- sum(lab)
  n.out <- n - n.in
  a <- 1 / n.in + 1 / n.out
  b <- -1 / n.out
  adv.of <- function(l) max(cumsum(l * a + b)[last])

  adv <- adv.of(lab)

  n.rep <- length(unique(rp))
  template <- rep(rep(c(TRUE, FALSE), each = n.in / n.rep), n.rep)
  null <- numeric(B)
  for (bb in 1:B) {
    l <- logical(n)
    l[order(rp, runif(n), method = "radix")] <- template
    null[bb] <- adv.of(l)
  }

  c(adv = adv, p = (1 + sum(null >= adv)) / (B + 1))
}

out <- NULL

for (ratio.val in ratio.seq) {

  ## Collect the first rep.m completed replicates of this setting.
  dat <- NULL
  n.used <- 0
  i <- 0
  while (n.used < rep.m) {
    i <- i + 1
    filename <- paste(
      "./Membership/Membership_N=", N.val,
      "_Rho=", rho.val,
      "_Rank=", rank.val,
      "_Index=", i,
      "_Ratio=", ratio.val,
      ".Rda",
      sep = ""
    )
    if (file.exists(filename)) {
      load(filename)
      dat <- rbind(dat, res)
      n.used <- n.used + 1
    }
    if (i > 10000) {
      stop(paste("fewer than", rep.m, "completed replicates for ratio", ratio.val))
    }
  }

  ## Centre the scores within each replicate before pooling. The centring does
  ## not depend on the labels and leaves the reference distribution exact.
  dat$score.nonprivate <- dat$score.nonprivate -
    ave(dat$score.nonprivate, dat$index, FUN = mean)
  dat$score.grand <- dat$score.grand -
    ave(dat$score.grand, dat$index, FUN = mean)

  is.in <- dat$label == "IN"

  res.nonprivate <- attack.advantage(dat$score.nonprivate, is.in, dat$index, B)
  res.grand <- attack.advantage(dat$score.grand, is.in, dat$index, B)

  out <- rbind(out, data.frame(
    m.over.N = ratio.val / 100,
    scored.per.group = sum(is.in),
    adv.nonprivate = unname(res.nonprivate["adv"]),
    p.nonprivate = unname(res.nonprivate["p"]),
    adv.grand = unname(res.grand["adv"]),
    p.grand = unname(res.grand["p"])
  ))
}

print(out, row.names = FALSE, digits = 3)
