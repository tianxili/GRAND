custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(igraph)
library(GRANDpriv)
library(clue)

## Recovery of the true community labels from the GRAND-privatized network.
## Networks are generated from a stochastic block model with three communities,
## size 4000 and average degree 200; spectral clustering is applied to the
## privatized released network at each privacy budget.

clusterAcc <- function(g1, g2) {
  # --------------------------------------------------------------------------
  # Arguments:
  #   g1: Vector of true cluster labels (integers or factors)
  #   g2: Vector of estimated cluster labels (integers or factors)
  #
  # Returns:
  #   Accuracy (float between 0 and 1) matching g2 to g1 optimally.
  # --------------------------------------------------------------------------

  # 1. Error handling and standardization
  if (length(g1) != length(g2)) {
    stop("Error: g1 and g2 must have the same length.")
  }

  # Ensure inputs are factors and share the same set of levels to create
  # a square contingency table.
  all_labels <- sort(unique(c(as.character(g1), as.character(g2))))

  g1 <- factor(g1, levels = all_labels)
  g2 <- factor(g2, levels = all_labels)

  # 2. Create the Contingency Table (Confusion Matrix)
  # Rows = True Labels, Columns = Estimated Labels
  tab <- table(g1, g2)

  # 3. Solve the Linear Sum Assignment Problem (Hungarian Algorithm)
  # We want to find a permutation of columns that maximizes the sum of the
  # diagonal elements (the matches).
  # solve_LSAP finds the best alignment. We use maximum = TRUE because
  # we want to maximize the counts of agreement.
  assignment <- solve_LSAP(tab, maximum = TRUE)

  # 4. Calculate Accuracy
  # assignment matches row i to column assignment[i].
  # We extract the counts from these optimal cells.

  # Extract the matched counts
  matched_counts <- tab[cbind(seq_along(assignment), assignment)]

  # Compute accuracy
  acc <- sum(matched_counts) / length(g1)

  return(acc)
}


eps.seq <- c(1, 2, 5, 10, 20, 30, 40, 50)
rep.m <- 100

## The replicates share one sequential random stream, so the loop is not run in
## parallel.
set.seed(999)

res.mat <- matrix(0, rep.m, length(eps.seq))

for (J in 1:rep.m) {

  dt <- BlockModel.Gen(lambda = 200, n = 4000, K = 3, beta = 0.2)
  A <- dt$A

  grand <- GRAND.privatize(
    A = A,
    K = 3,
    idx = 1:2000,
    eps = eps.seq,
    model = "RDPG",
    rho = 0.05,
    verbose = TRUE
  )

  grand.acc <- rep(0, length(eps.seq))
  for (k in 1:length(eps.seq)) {
    tilde.A1 <- grand$GRAND.result[[k]]$A1.grand
    grand.sc <- reg.SP(tilde.A1, K = 3, tau = 0)
    grand.acc[k] <- clusterAcc(g1 = dt$g[1:2000], g2 = grand.sc$cluster)
  }

  res.mat[J, ] <- grand.acc
}

## Mean accuracy at each privacy budget.
colMeans(res.mat)

save(res.mat, eps.seq, file = "SBM_Community_Recovery.Rda")
