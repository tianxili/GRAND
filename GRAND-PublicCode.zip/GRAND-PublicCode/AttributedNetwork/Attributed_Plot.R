custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(ggplot2)
library(dplyr)
library(scales)
library(gridExtra)
library(grid)

## Paired heatmaps of the joint distribution of community and attribute, true
## above and GRAND below, one PDF per attribute. The colour of each cell is the
## proportion of that combination of values.

load("AttributeTables.Rda")

Ts <- list(T1 = T1, T2 = T2, T3 = T3, T4 = T4,
           T5 = T5, T6 = T6, T7 = T7, T8 = T8)

pair_info <- list(
  list(name = "P1", true = "T1", grand = "T2", xlabel = "Gender"),
  list(name = "P2", true = "T3", grand = "T4", xlabel = "Grade"),
  list(name = "P3", true = "T5", grand = "T6", xlabel = "Workshop"),
  list(name = "P4", true = "T7", grand = "T8", xlabel = "Language")
)

## Each pair must have identical dimensions.
for (pi in pair_info) {
  a <- Ts[[pi$true]]; b <- Ts[[pi$grand]]
  if (!identical(dim(a), dim(b))) {
    stop(sprintf("Dimension mismatch in %s: %s is %sx%s but %s is %sx%s",
                 pi$name, pi$true, nrow(a), ncol(a), pi$grand, nrow(b), ncol(b)))
  }
}

# ---- Long format helper ----
to_long <- function(m) {
  rn <- rownames(m); cn <- colnames(m)
  if (is.null(rn)) rn <- paste0("C", seq_len(nrow(m)))
  if (is.null(cn)) cn <- paste0("L", seq_len(ncol(m)))
  idx <- arrayInd(seq_along(m), dim(m))
  data.frame(
    Community = factor(rn[idx[,1]], levels = rev(rn)),
    X         = factor(cn[idx[,2]], levels = cn),
    value     = as.vector(m),
    stringsAsFactors = FALSE
  )
}

# SAME palette and SAME range for all heatmaps
fill_limits <- c(0, 1)

heat_one <- function(m, title_txt, xlab_txt, digits = 2, text_size = 3.4) {
  dat <- to_long(m)
  ggplot(dat, aes(x = X, y = Community, fill = value)) +
    geom_tile(color = "white", linewidth = 0.5) +
    geom_text(aes(label = number(value, accuracy = 10^(-digits))),
              size = text_size) +
    coord_equal() +
    scale_fill_gradient(
      low = "#F7FBFF", high = "#08306B",
      limits = fill_limits, oob = squish
    ) +
    labs(title = title_txt, x = xlab_txt, y = "Community") +
    theme_minimal(base_size = 12) +
    theme(
      panel.grid = element_blank(),
      plot.title = element_text(face = "bold", hjust = 0.5, margin = margin(b = 6)),
      axis.title = element_text(face = "bold"),
      axis.text  = element_text(face = "bold"),
      legend.position = "none"
    )
}

# ---- Output sizing: constant height across PDFs; width depends on columns ----
height_in <- 6.5
cell_w_in <- 0.60   # width per column
left_in   <- 2.2
right_in  <- 0.6
min_w_in  <- 5.0

# Optional: adapt font size a bit to total cells so it stays readable
text_size_from_dim <- function(nr, nc) {
  cells <- nr * nc
  if (cells <= 12) return(3.8)
  if (cells <= 25) return(3.4)
  if (cells <= 40) return(3.0)
  2.6
}

for (pi in pair_info) {
  m_true  <- Ts[[pi$true]]
  m_grand <- Ts[[pi$grand]]
  nr <- nrow(m_true); nc <- ncol(m_true)

  width_in <- max(min_w_in, left_in + right_in + cell_w_in * nc)
  txt_sz   <- text_size_from_dim(nr, nc)

  p_top <- heat_one(m_true,  "True",  pi$xlabel, digits = 2, text_size = txt_sz)
  p_bot <- heat_one(m_grand, "GRAND", pi$xlabel, digits = 2, text_size = txt_sz)

  g <- arrangeGrob(p_top, p_bot, ncol = 1, heights = c(1, 1))

  outfile <- sprintf("%s_%s_True_GRAND.pdf", pi$name, pi$xlabel)

  grDevices::pdf(outfile, width = width_in, height = height_in, useDingbats = FALSE)
  tryCatch({ grid.newpage(); grid.draw(g) }, finally = { dev.off() })
}
