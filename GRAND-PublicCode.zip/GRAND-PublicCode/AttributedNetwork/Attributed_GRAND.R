custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(igraph)
library(GRANDpriv)

## GRAND for attributed networks. The node attributes are treated as additional
## coordinates of the latent vector, so that the privatization in Step 6 is
## applied to the latent positions and the attributes jointly.

GRAND.Y <- function (A, K, idx, eps = 1, model = c("LSM", "RDPG"),Y, niter = 500,
    rho = 0.05, verbose = TRUE)
{
    model <- match.arg(model)
    n <- nrow(A)
    n1 <- length(idx)
    n2 <- n - n1
    holdout.idx <- setdiff(1:n, idx)
    A11 <- A[idx, idx]
    g1 <- graph.adjacency(A11, "undirected")
    A22 <- A[holdout.idx, holdout.idx]
    g2 <- graph.adjacency(A22, "undirected")
    fit <- GRAND.estimate(A = A, K = K, holdout.index = holdout.idx,
        release.index = idx, model = model, niter = niter, verbose = verbose)
    X.trans <- if (model == "LSM")
        cbind(fit$alpha, fit$Z)
    else fit$Z
    X1.hat <- X.trans[idx, , drop = FALSE]
    X2.hat <- X.trans[holdout.idx, , drop = FALSE]
    if (model == "LSM") {
        alpha1.hat <- X1.hat[, 1, drop = FALSE]
        Z1.hat <- X1.hat[, -1, drop = FALSE]
        theta1.hat <- alpha1.hat %*% t(rep(1, n1)) + rep(1, n1) %*%
            t(alpha1.hat) + Z1.hat %*% t(Z1.hat)
        P1.hat <- 1/(1 + exp(-theta1.hat))
    }
    else {
        Z1.hat <- X1.hat
        theta1.hat <- Z1.hat %*% t(Z1.hat)
        P1.hat <- pmin(pmax(theta1.hat, 1e-05), 1 - 1e-05)
    }
    A1.hat <- gen.A.from.P(P1.hat)
    g1.hat <- graph.adjacency(A1.hat, "undirected")
    if (model == "LSM") {
        alpha2.hat <- X2.hat[, 1, drop = FALSE]
        Z2.hat <- X2.hat[, -1, drop = FALSE]
        theta2.hat <- alpha2.hat %*% t(rep(1, n2)) + rep(1, n2) %*%
            t(alpha2.hat) + Z2.hat %*% t(Z2.hat)
        P2.hat <- 1/(1 + exp(-theta2.hat))
    }
    else {
        Z2.hat <- X2.hat
        theta2.hat <- Z2.hat %*% t(Z2.hat)
        P2.hat <- pmin(pmax(theta2.hat, 1e-05), 1 - 1e-05)
    }
    A2.hat <- gen.A.from.P(P2.hat)
    g2.hat <- graph.adjacency(A2.hat, "undirected")
    non.private.result <- list(A1 = A11, A2 = A22, A1.hat = A1.hat,
        A2.hat = A2.hat, P1.hat = P1.hat, P2.hat = P2.hat, g1 = g1,
        g2 = g2, g1.hat = g1.hat, g2.hat = g2.hat, X1.hat = X1.hat,
        X2.hat = X2.hat)
    L <- length(eps)
    GRAND.result <- list()
    Y1 <- Y[idx,,drop=FALSE]
    Y2 <- Y[holdout.idx,,drop=FALSE]
    p <- ncol(Y)
    for (jj in 1:L) {
        if (verbose)
            cat(paste0("Calling GRAND with ε=", eps[jj], ".\n"))
        X1.dip <- DIP.multivariate(cbind(X1.hat,Y1), eps[jj], cbind(X2.hat,Y2), rho)
        Y1.dip <- X1.dip[,(ncol(X1.hat)+1):(ncol(X1.hat)+p)]
        X1.dip <- X1.dip[1:ncol(X1.hat)]
        if (model == "LSM") {
            alpha1.dip <- X1.dip[, 1, drop = FALSE]
            Z1.dip <- X1.dip[, -1, drop = FALSE]
            theta1.dip <- alpha1.dip %*% t(rep(1, n1)) + rep(1,
                n1) %*% t(alpha1.dip) + Z1.dip %*% t(Z1.dip)
            P1.dip <- 1/(1 + exp(-theta1.dip))
        }
        else {
            Z1.dip <- X1.dip
            theta1.dip <- Z1.dip %*% t(Z1.dip)
            P1.dip <- pmin(pmax(theta1.dip, 1e-05), 1 - 1e-05)
        }
        A1.dip <- gen.A.from.P(P1.dip)
        g1.dip <- graph.adjacency(A1.dip, "undirected")
        GRAND.result[[jj]] <- list(A1.grand = A1.dip, P1.grand = P1.dip,
            g1.grand = g1.dip, X1.grand = X1.dip,Y1.grand=Y1.dip)
    }
    if (verbose)
        cat("Finish GRAND.\n")
    Laplace.result <- list()
    for (jj in 1:L) {
        if (verbose)
            cat(paste0("Calling Laplace with ε=", eps[jj], ".\n"))
        X1.Lap <- Add.Laplace(X = cbind(X1.hat,Y1), eps = eps[jj])
        Y1.Lap <- X1.Lap[,(ncol(X1.hat)+1):(ncol(X1.hat)+p)]
        X1.Lap <- X1.Lap[1:ncol(X1.hat)]

        if (model == "LSM") {
            alpha1.Lap <- X1.Lap[, 1, drop = FALSE]
            Z1.Lap <- X1.Lap[, -1, drop = FALSE]
            theta1.Lap <- alpha1.Lap %*% t(rep(1, n1)) + rep(1,
                n1) %*% t(alpha1.Lap) + Z1.Lap %*% t(Z1.Lap)
            P1.Lap <- 1/(1 + exp(-theta1.Lap))
        }
        else {
            Z1.Lap <- X1.Lap
            theta1.Lap <- Z1.Lap %*% t(Z1.Lap)
            P1.Lap <- pmin(pmax(theta1.Lap, 1e-05), 1 - 1e-05)
        }
        A1.Lap <- gen.A.from.P(P1.Lap)
        g1.Lap <- graph.adjacency(A1.Lap, "undirected")
        Laplace.result[[jj]] <- list(A1.Lap = A1.Lap, P1.Lap = P1.Lap,
            g1.Lap = g1.Lap, X1.Lap = X1.Lap,Y1.Lap=Y1.Lap)
    }
    if (verbose)
        cat("Finish Laplace.\n")
    return(list(non.private.result = non.private.result, GRAND.result = GRAND.result,
        Laplace.result = Laplace.result, eps = eps))
}


## ---------------------------------------------------------------------------
## The friendship network and its node attributes, derived from ICPSR study
## 37070. See the README for how to obtain the study; the processed objects
## below are not redistributable.
##   G      : averaged friendship adjacency matrix over all schools
##   X.true : node covariates, columns 6:29 being the school indicators
##   Y       : node attribute matrix (Gender, Grade, Workshop, Language, ...)
load("averge_network.Rda")
load("X_true.Rda")
load("Y.Rda")

X.true <- X.true[, c(1, 5, 6, 7, 12:36)]
A_new <- G

## Restrict to a single school.
sch.mat <- X.true[, 6:29]
base.school <- rep(0, nrow(sch.mat))
base.school[rowSums(sch.mat) == 0] <- 1
sch.mat <- cbind(sch.mat, base.school)
sch.label <- apply(sch.mat, 1, which.max)

index <- which(sch.label == 7)

X <- X.true[index, 2:5]
A <- A_new[index, index]
Y <- Y[index, ]

n <- nrow(A)

set.seed(999)

release.index <- sample(n, size = floor(n / 2))
holdout.index <- setdiff(1:n, release.index)

A11 <- A[release.index, release.index]

df <- cbind(X, Y)

result <- GRAND.Y(A = A, K = 2, idx = release.index, model = "LSM",
                  eps = 1, niter = 4000, Y = df, rho = 0.01)

## Two communities in the true and in the privatized released network. Community
## labels are identified only up to a permutation, so the second labelling is
## matched to the first.
cl1 <- reg.SSP(A11, K = 2, tau = 0)
cl2 <- reg.SSP(as.matrix(result$GRAND.result[[1]]$A1.grand), K = 2, tau = 0)
cl2$cluster <- 3 - cl2$cluster

## Joint distribution of community and attribute, true and privatized, for each
## of the four attributes.
Y.grand <- result$GRAND.result[[1]]$Y1.grand

T1 <- table(cl1$cluster, df[release.index, 1]) / nrow(A11)   # Gender, true
T2 <- table(cl2$cluster, Y.grand[, 1]) / nrow(A11)           # Gender, GRAND

T3 <- table(cl1$cluster, df[release.index, 2]) / nrow(A11)   # Grade, true
T4 <- table(cl2$cluster, Y.grand[, 2]) / nrow(A11)           # Grade, GRAND
T3 <- T3[, -1]

T5 <- table(cl1$cluster, df[release.index, 3]) / nrow(A11)   # Workshop, true
T6 <- table(cl2$cluster, Y.grand[, 3]) / nrow(A11)           # Workshop, GRAND

T7 <- table(cl1$cluster, df[release.index, 4]) / nrow(A11)   # Language, true
T8 <- table(cl2$cluster, Y.grand[, 4]) / nrow(A11)           # Language, GRAND

save(T1, T2, T3, T4, T5, T6, T7, T8, file = "AttributeTables.Rda")
