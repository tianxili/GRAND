custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(plyr)

## Summarizes the saved evaluation into the five scatterplots of the Wasserstein
## distance under GRAND against the Laplace mechanism, one per local statistic,
## with one point per network.

load("CommunityFitNet-Social-Evaluation.Rda")

r1 <- lapply(all.result, function(x) {
  ddply(x$r1, .(metric), function(s) colMeans(s[1, c(3, 4, 5, 6)]))
})

## Row of the per-network summary holding each statistic, and its plotting range.
stat.info <- list(
  list(row = 1, file = "500Social-Degree.pdf",   lim = c(0, 5)),
  list(row = 5, file = "500Social-Vshape.pdf",   lim = c(0, 9)),
  list(row = 4, file = "500Social-Triangle.pdf", lim = c(0, 9)),
  list(row = 2, file = "500Social-Eigen.pdf",    lim = c(0, 1)),
  list(row = 3, file = "500Social-Harmonic.pdf", lim = c(0, 350))
)

for (s in stat.info) {
  res <- matrix(unlist(lapply(r1, function(x) x[s$row, 4:5])),
                ncol = 2, byrow = TRUE)

  pdf(s$file, height = 5, width = 5)
  plot(res[, 1], res[, 2], xlim = s$lim, ylim = s$lim, pch = 20,
       col = "firebrick", xlab = "GRAND", ylab = "Laplace", cex.lab = 1.3)
  abline(a = 0, b = 1, lty = 2)
  dev.off()
}
