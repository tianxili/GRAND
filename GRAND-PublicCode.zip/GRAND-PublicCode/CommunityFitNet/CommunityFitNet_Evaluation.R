custom_lib_path <- "./Rlibs"
.libPaths(custom_lib_path)

library(randnet)
library(igraph)
library(transport)
library(doParallel)

registerDoParallel(20)

## Core GRAND functions.
source("../GraphDIP-Source.R")

## Evaluation on the social networks of the CommunityFitNet collection with more
## than 200 nodes. For each network the latent dimension is selected by edge
## cross-validation, GRAND and the Laplace mechanism are applied at the same
## privacy budgets, and the Wasserstein distances between the privatized and the
## true distributions of the local statistics are recorded.

load("SocialGList.Rda")

sizes <- unlist(lapply(graph.list, function(x) length(V(x))))
index <- which(sizes > 200)

dir.create("SocialResults", showWarnings = FALSE)

all.result <- foreach(k = 1:length(index), .errorhandling = "pass") %dopar% {

  set.seed(999)

  g <- graph.list[[index[k]]]
  A <- get.adjacency(g, "both")
  n <- nrow(A)

  release.index <- sample(n, size = floor(n / 2))
  holdout.index <- setdiff(1:n, release.index)

  A22 <- A[holdout.index, holdout.index]

  ecv.result <- ECV.LSM(A22, niter = 2000)

  if (length(ecv.result) > 0) {
    d.hat <- ecv.result$cv.which.min

    result <- LSM.NDP.combined.all(A = as.matrix(A), K = d.hat,
                                   idx = release.index,
                                   eps = c(1, 2, 5, 10), niter = 5000)
    result$non.private.result$g1.hat <- graph.adjacency(A22, "undirected")

    tmp <- list(r1 = DIP.eval.summary(result))

    save(tmp, file = paste("./SocialResults/Results_SocialIndex_",
                           index[k], ".Rda", sep = ""))
  } else {
    tmp <- NA
  }

  tmp
}

save(all.result, file = "CommunityFitNet-Social-Evaluation.Rda")
