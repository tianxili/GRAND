custom_lib_path <- "~/Rlibs"
# Add the custom library path to the current R session
.libPaths(custom_lib_path)
source("GraphDIP-Source-Final.R")
library(doParallel)

registerDoParallel(20)

library(randnet)


rep.m <- 100

N.seq <- c(1000,2000,3000,4000)
rho.seq <- c(0.025,0.05,0.1)
rank.seq <- c(3,6)

for(I1 in 1:length(N.seq)){
  for(I2 in 1:length(rho.seq)){
    for(I3 in 1:length(rank.seq)){
      N.val <- N.seq[I1]
      rho.val <- rho.seq[I2]
      rank.val <- rank.seq[I3]
      
      result <- foreach(i = 1:rep.m,.errorhandling ="pass")%dopar%{
        m <- N.val
        n <- N.val
        dt <- RDPG.Gen(n = m+n, K = rank.val, directed = FALSE, avg.d = rho.val*(m+n))
        A <- dt$A
        idx <- 1:n
        test1 <- RDPG.NDP.combined.all(A,rank.val,idx,eps=c(1,2,5,10),oracle.dt = dt)
        res <- DIP.eval.summary(test1)
        res2 <- DIP.eval.summary.KS(test1)
        
        filename <- paste("./RDPG_Results/NewDIP_RDPG_Rank=",rank.val,"_N=",N.val,"_Rho=",rho.val,"_Index_",i,"_Result.Rda",sep="")
        save(res,res2,file=filename)
        gc()
        tmp <- i
      }
      
      
      
    }
  }
}


